package MisVentanas;

import MisExcepciones.DatoLogicoException;
import MisExcepciones.VacioException;
import java.awt.Color;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import proyectodaw.ProyectoDAW;
import MisClases.Vehiculo;
import java.awt.Font;

public class DAdminVehiculos extends javax.swing.JDialog {

    public DAdminVehiculos(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cbMarca = new javax.swing.JComboBox<>();
        tfModelo = new javax.swing.JTextField();
        tfPeso = new javax.swing.JTextField();
        tfMatricula = new javax.swing.JTextField();
        bInsertar = new javax.swing.JButton();
        bModificar = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("VEHÍCULOS");

        jLabel2.setText("* Marca:");

        jLabel3.setText("Modelo:");

        jLabel4.setText("Peso:");

        jLabel5.setText("* Matrícula:");

        cbMarca.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Renault", "Mercedes", "Ford", "Morgan Olson" }));

        tfModelo.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tfModeloFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfModeloFocusLost(evt);
            }
        });

        tfPeso.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tfPesoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfPesoFocusLost(evt);
            }
        });

        tfMatricula.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfMatriculaFocusLost(evt);
            }
        });

        bInsertar.setText("Insertar");
        bInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bInsertarActionPerformed(evt);
            }
        });

        bModificar.setText("Modificar");
        bModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bModificarActionPerformed(evt);
            }
        });

        jMenu3.setText("Ventana");

        jMenuItem1.setText("Cerrar ventana");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem1);

        jMenuBar1.add(jMenu3);

        jMenu1.setText("Acciones");

        jMenuItem2.setText("Insertar");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuItem3.setText("Modificar");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuItem4.setText("Borrar");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem4);

        jMenuBar1.add(jMenu1);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGap(41, 41, 41)
                            .addComponent(bModificar)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(bInsertar))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGap(52, 52, 52)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel5)
                                .addComponent(jLabel2)
                                .addComponent(jLabel4)
                                .addComponent(jLabel3))
                            .addGap(18, 18, 18)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(tfMatricula, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(cbMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tfPeso, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(tfModelo, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(147, 147, 147)
                        .addComponent(jLabel1)))
                .addContainerGap(68, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cbMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(tfMatricula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(tfPeso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(tfModelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bModificar)
                    .addComponent(bInsertar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        ProyectoDAW.cerrarVentanaVehiculos();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void bInsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bInsertarActionPerformed
        if (comprobarTextos()) {
            int peso = 0;
            if (tfPeso.getText().isEmpty()==false) {
                peso = Integer.parseInt(tfPeso.getText());
            }
            ProyectoDAW.insertarVehiculo(cbMarca.getSelectedItem().toString(), tfMatricula.getText(), peso, tfModelo.getText());
            borrarTextos();
        }
    }//GEN-LAST:event_bInsertarActionPerformed

    private void tfMatriculaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfMatriculaFocusLost
        if (existe(tfMatricula.getText())) {
            JOptionPane.showMessageDialog(this, "Se ha encontrado un vehiculo con esa matricula");
            Vehiculo ve = ProyectoDAW.getVehiculoActual();
            tfMatricula.setText(ve.getMatricula());
            cbMarca.setSelectedIndex(setMarca(ve.getMarca()));
            tfModelo.setText(ve.getModelo());
            tfPeso.setText(ve.getPeso()+"");
        }
    }//GEN-LAST:event_tfMatriculaFocusLost

    private void tfPesoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfPesoFocusGained
        if (modificar)
            casillaSelect = tfPeso.getText();
    }//GEN-LAST:event_tfPesoFocusGained

    private void tfModeloFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfModeloFocusGained
        if (modificar)
            casillaSelect = tfModelo.getText();
    }//GEN-LAST:event_tfModeloFocusGained

    private void tfPesoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfPesoFocusLost
        if (modificar) {
            if (!casillaSelect.equals(tfPeso.getText()))
                tfPeso.setBackground(Color.green);
        }
    }//GEN-LAST:event_tfPesoFocusLost

    private void tfModeloFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfModeloFocusLost
        if (modificar) {
            if (!casillaSelect.equals(tfModelo.getText()))
                tfModelo.setBackground(Color.green);
        }
    }//GEN-LAST:event_tfModeloFocusLost

    private void bModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bModificarActionPerformed
        if (modificar) {
            if (comprobarTextos()) {
                modificar=false;
                Font normal = new Font("Tahoma",Font.PLAIN,11);
                bModificar.setForeground(Color.black);
                bModificar.setFont(normal);
                Vehiculo ve = ProyectoDAW.getVehiculoActual();
                if (tfModelo.getBackground()==Color.green)
                    ve.setModelo(tfModelo.getText());
                if (tfPeso.getBackground()==Color.green)
                    ve.setPeso(Integer.parseInt(tfPeso.getText()));
                ve.setMarca(cbMarca.getSelectedItem().toString());
                ProyectoDAW.modificarVehiculo(ve);
                borrarTextos();
            }
        }
        else
            ProyectoDAW.mostrarVentanaOpciones("vehiculo");
    }//GEN-LAST:event_bModificarActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        bInsertar.doClick();
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        if (modificar)
            bModificar.doClick();
        else
            recogerOpcion("modificar");
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
        if (modificar)
            JOptionPane.showMessageDialog(this, "Modo modificar activado");
        else
            recogerOpcion("baja");
    }//GEN-LAST:event_jMenuItem4ActionPerformed

    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DAdminVehiculos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DAdminVehiculos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DAdminVehiculos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DAdminVehiculos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                DAdminVehiculos dialog = new DAdminVehiculos(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }
    
    public boolean existe(String mat) {
        return ProyectoDAW.comprobarMatricula(mat);
    }
    
    public static int setMarca(String marca) {
        int x;
        switch (marca) {
            case "Renault":
                x=0;
                break;
            case "Mercedes":
                x=1;
                break;
            case "Ford":
                x=2;
                break;
            case "Morgan Olson":
                x=3;
                break;
            default:
                x=-1;
        }
        return x;
    }
    
    public void recogerOpcion(String opcion) {
        String nombreVehiculo;
        if (tfMatricula.getText().isEmpty())
            nombreVehiculo = JOptionPane.showInputDialog(this, "Introduzca la matricula del vehiculo que desea "+opcion);
        else
            nombreVehiculo = tfMatricula.getText();
        if (ProyectoDAW.comprobarMatricula(nombreVehiculo)==false) {
            JOptionPane.showMessageDialog(this, "No se ha encontrado un vehiculo con esa matricula");
        }
        else {
            if (opcion.equals("modificar")) {
                Vehiculo ve = ProyectoDAW.getVehiculoActual();
                tfMatricula.setText(ve.getMatricula());
                tfModelo.setText(ve.getModelo());
                tfPeso.setText(ve.getPeso()+"");
                cbMarca.setSelectedIndex(setMarca(ve.getMarca()));
                modificar=true;
                Font negrita = new Font("Tahoma",Font.BOLD,12);
                bModificar.setForeground(Color.green);
                bModificar.setFont(negrita);
            }
            else {
                ProyectoDAW.borrarVehiculo();
                borrarTextos();
            }
        }
    }
    
    public boolean comprobarTextos() {
        try {
            Pattern pat;
            Matcher mat;
            if (tfMatricula.getText().isEmpty())
                throw new VacioException("matricula");
            if (tfPeso.getText().isEmpty()==false) {
                pat =  Pattern.compile("^[0-9]*$");
                mat = pat.matcher(tfPeso.getText());
                if (mat.matches()==false)
                    throw new DatoLogicoException("Peso");
            }
            pat =  Pattern.compile("^[0-9]{4} [A-Z]{3}$");
            mat = pat.matcher(tfMatricula.getText());
            if (mat.matches()==false)
                throw new DatoLogicoException("matricula");
            return true;
        }
        catch (DatoLogicoException e) {
            String mano = "";
            if (DatoLogicoException.getMensaje().equals("mano"))
                mano = ".\nLos valores deben ser A,B,C,D,E,F o I.";
            JOptionPane.showMessageDialog(this, "El campo de "+DatoLogicoException.getMensaje()+" no está bien escrito"+mano);
        }
        catch (VacioException e){
            JOptionPane.showMessageDialog(this, "El campo de "+VacioException.getMensaje()+" está vacio");
        }
        return false;
    }
    
    public void borrarTextos() {
        tfMatricula.setText("");
        tfMatricula.setBackground(Color.white);
        tfPeso.setText("");
        tfPeso.setBackground(Color.white);
        tfModelo.setText("");
        tfModelo.setBackground(Color.white);
    }

    private boolean modificar = false;
    private String casillaSelect;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bInsertar;
    private javax.swing.JButton bModificar;
    private javax.swing.JComboBox<String> cbMarca;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JTextField tfMatricula;
    private javax.swing.JTextField tfModelo;
    private javax.swing.JTextField tfPeso;
    // End of variables declaration//GEN-END:variables
}
