package MisVentanas;

import MisClases.Trabajador;
import MisExcepciones.DatoLogicoException;
import MisExcepciones.VacioException;
import java.awt.Color;
import java.awt.Font;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import proyectodaw.ProyectoDAW;

public class DAdminTrabajador extends javax.swing.JDialog {

    public DAdminTrabajador(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setLocationRelativeTo(null);
        sdf = new SimpleDateFormat("yyyy-MM-dd");
        dcFNacimiento.setDateFormat(sdf);
        ArrayList<String> listanombres = ProyectoDAW.nombreCentros();
        for (int x=0;x<listanombres.size();x++) {
            cbCentro.insertItemAt(listanombres.get(x), x);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        tfDni = new javax.swing.JTextField();
        tfApeUno = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        tfNombre = new javax.swing.JTextField();
        tfApeDos = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        tfCalle = new javax.swing.JTextField();
        tfPiso = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        tfPortal = new javax.swing.JTextField();
        tfMano = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        tfTPersonal = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        tfTEmpresa = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        tfSalario = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        cbTipo = new javax.swing.JComboBox<>();
        jCheckBox1 = new javax.swing.JCheckBox();
        dcFNacimiento = new datechooser.beans.DateChooserCombo();
        jLabel14 = new javax.swing.JLabel();
        cbCentro = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        mbAcciones = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Control de trabajadores");
        setResizable(false);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Trabajadores");

        jLabel2.setText("* DNI:");

        jLabel3.setText("* Primer Apellido:");

        tfDni.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tfDniFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfDniFocusLost(evt);
            }
        });

        tfApeUno.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tfApeUnoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfApeUnoFocusLost(evt);
            }
        });

        jLabel4.setText("* Nombre:");

        jLabel5.setText("* Segundo apellido:");

        tfNombre.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tfNombreFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfNombreFocusLost(evt);
            }
        });

        tfApeDos.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tfApeDosFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfApeDosFocusLost(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Dirección"));

        jLabel6.setText("* Calle:");

        jLabel7.setText("* Piso:");

        tfCalle.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tfCalleFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfCalleFocusLost(evt);
            }
        });
        tfCalle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfCalleActionPerformed(evt);
            }
        });

        tfPiso.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tfPisoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfPisoFocusLost(evt);
            }
        });

        jLabel8.setText("* Portal:");

        jLabel9.setText("* Mano");

        tfPortal.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tfPortalFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfPortalFocusLost(evt);
            }
        });

        tfMano.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tfManoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfManoFocusLost(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel7)
                    .addComponent(jLabel6))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tfCalle, javax.swing.GroupLayout.DEFAULT_SIZE, 159, Short.MAX_VALUE)
                    .addComponent(tfPiso))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tfPortal, javax.swing.GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE)
                    .addComponent(tfMano))
                .addContainerGap(18, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(tfCalle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(tfPortal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(tfPiso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(tfMano, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Teléfonos"));

        jLabel10.setText("Personal:");

        tfTPersonal.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tfTPersonalFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfTPersonalFocusLost(evt);
            }
        });
        tfTPersonal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfTPersonalActionPerformed(evt);
            }
        });

        jLabel11.setText("* Empresa:");

        tfTEmpresa.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tfTEmpresaFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfTEmpresaFocusLost(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addGap(18, 18, 18)
                .addComponent(tfTPersonal, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel11)
                .addGap(18, 18, 18)
                .addComponent(tfTEmpresa, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(tfTPersonal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(tfTEmpresa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel12.setText("Salario:");

        tfSalario.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tfSalarioFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfSalarioFocusLost(evt);
            }
        });

        jLabel13.setText("* Tipo:");

        cbTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Logistica", "Administracion" }));

        jCheckBox1.setText("Fecha de Nacimiento");
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });

        dcFNacimiento.setEnabled(false);

        jLabel14.setText("* Centro:");

        jButton1.setText("Insertar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Modificar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Acceso");
        jButton3.setEnabled(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jMenu3.setText("Ventana");

        jMenuItem1.setText("Cerrar");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem1);

        jMenuBar1.add(jMenu3);

        mbAcciones.setText("Acciones");

        jMenuItem2.setText("Alta");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        mbAcciones.add(jMenuItem2);

        jMenuItem3.setText("Baja");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        mbAcciones.add(jMenuItem3);

        jMenuItem4.setText("Modificar");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        mbAcciones.add(jMenuItem4);

        jMenuBar1.add(mbAcciones);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tfApeUno, javax.swing.GroupLayout.DEFAULT_SIZE, 128, Short.MAX_VALUE)
                            .addComponent(tfDni))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tfNombre, javax.swing.GroupLayout.DEFAULT_SIZE, 128, Short.MAX_VALUE)
                            .addComponent(tfApeDos))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(209, 209, 209)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel13)
                            .addComponent(jLabel12)
                            .addComponent(jLabel14))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(tfSalario)
                                    .addComponent(cbTipo, 0, 158, Short.MAX_VALUE)
                                    .addComponent(cbCentro, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(66, 66, 66)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jCheckBox1)
                                    .addComponent(dcFNacimiento, javax.swing.GroupLayout.DEFAULT_SIZE, 172, Short.MAX_VALUE)
                                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton1)
                                .addGap(100, 100, 100)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfDni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel4)
                    .addComponent(tfNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfApeUno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfApeDos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel3))
                .addGap(34, 34, 34)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(tfSalario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jCheckBox1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel13)
                        .addComponent(cbTipo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(dcFNacimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(cbCentro, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addContainerGap(35, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBox1ActionPerformed
        if (cheked) {
            dcFNacimiento.setEnabled(false);
            cheked=false;
        }
        else {
            dcFNacimiento.setEnabled(true);
            cheked=true;
        }
    }//GEN-LAST:event_jCheckBox1ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        ProyectoDAW.cerrarVentanaTrabajadores();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void tfDniFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfDniFocusLost
        mostrarDatos(tfDni.getText());
    }//GEN-LAST:event_tfDniFocusLost

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        if (modificar) {
            if (comprobarTextos()) {
                modificar=false;
                jButton3.setEnabled(false);
                tfDni.setEnabled(true);
                cbCentro.setEnabled(true);
                cbTipo.setEnabled(true);
                Font normal = new Font("Tahoma",Font.PLAIN,11);
                jButton2.setForeground(Color.black);
                jButton2.setFont(normal);
                Trabajador tra = ProyectoDAW.getTrabajadorActual();
                if (tfNombre.getBackground()==Color.green)
                    tra.setNombre(tfNombre.getText());
                if (tfApeUno.getBackground()==Color.green)
                    tra.setApeuno(tfApeUno.getText());
                if (tfApeDos.getBackground()==Color.green)
                    tra.setApedos(tfApeDos.getText());
                if (tfCalle.getBackground()==Color.green)
                    tra.getDireccion().setCalle(tfCalle.getText());
                if (tfPiso.getBackground()==Color.green)
                    tra.getDireccion().setPiso(Integer.parseInt(tfPiso.getText()));
                if (tfPortal.getBackground()==Color.green)
                    tra.getDireccion().setNumero(Integer.parseInt(tfPortal.getText()));
                if (tfMano.getBackground()==Color.green)
                    tra.getDireccion().setMano(tfMano.getText());
                if (tfTPersonal.getBackground()==Color.green)
                    tra.setTelefonoPersonal(tfTPersonal.getText());
                if (tfTEmpresa.getBackground()==Color.green)
                    tra.setTelefonoEmpresa(tfTEmpresa.getText());
                if (tfSalario.getBackground()==Color.green)
                    tra.setSalario(Double.parseDouble(tfSalario.getText()));
                if (dcFNacimiento.isEnabled()) {
                    sdf = new SimpleDateFormat("yyyy-MM-dd");
                    String a = sdf.format(dcFNacimiento.getSelectedDate().getTime());
                    tra.setFechaNac(a);
                }
                ProyectoDAW.actualizarTrabajador(tra);
                borrarTextos();
            }
        }
        else
            ProyectoDAW.mostrarVentanaOpciones("trabajador");
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (comprobarTextos()) {
            if (ProyectoDAW.buscarTrabajador(tfDni.getText())==false) {
                //personal salario y fecha pueden ser null
                Double salario;
                if (tfSalario.getText().isEmpty()) salario=null;
                else salario=Double.parseDouble(tfSalario.getText());
                String fecha;
                if (dcFNacimiento.isEnabled()) { 
                    sdf = new SimpleDateFormat("yyyy-MM-dd");
                    fecha=sdf.format(dcFNacimiento.getSelectedDate().getTime());
                }
                else fecha=null;
                String tper;
                if (tfTPersonal.getText().isEmpty()) tper=null;
                else tper=tfTPersonal.getText();
                //Aqui veremos dd que tipo es
                String tipo;
                if (cbTipo.getSelectedItem().toString().equals("Administracion"))
                    tipo = "A";
                else
                    tipo = "L";
                ProyectoDAW.insertarTrabajador(tfDni.getText(), tfNombre.getText(), tfApeUno.getText(), tfApeDos.getText(), tfCalle.getText(), Integer.parseInt(tfPortal.getText()), Integer.parseInt(tfPiso.getText()), tfMano.getText(), tper, tfTEmpresa.getText(), salario, fecha, cbCentro.getSelectedItem().toString(),tipo);
            }
            else
                JOptionPane.showMessageDialog(this, "El trabajador ya esta registrado");
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void tfNombreFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfNombreFocusGained
        if (modificar==true) {
            casillaSelect=tfNombre.getText();
        }
    }//GEN-LAST:event_tfNombreFocusGained

    private void tfDniFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfDniFocusGained
        if (modificar==true) {
            casillaSelect=tfDni.getText();
        }
    }//GEN-LAST:event_tfDniFocusGained

    private void tfApeUnoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfApeUnoFocusGained
        if (modificar==true) {
            casillaSelect=tfApeUno.getText();
        }
    }//GEN-LAST:event_tfApeUnoFocusGained

    private void tfApeDosFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfApeDosFocusGained
    if (modificar==true) {
            casillaSelect=tfApeDos.getText();
    }
    }//GEN-LAST:event_tfApeDosFocusGained

    private void tfCalleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfCalleActionPerformed
        
    }//GEN-LAST:event_tfCalleActionPerformed

    private void tfPortalFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfPortalFocusGained
        if (modificar==true) {
            casillaSelect=tfPortal.getText();
        }
    }//GEN-LAST:event_tfPortalFocusGained

    private void tfPisoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfPisoFocusGained
        if (modificar==true) {
            casillaSelect=tfPiso.getText();
        }
    }//GEN-LAST:event_tfPisoFocusGained

    private void tfManoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfManoFocusGained
        if (modificar==true) {
            casillaSelect=tfMano.getText();
        }
    }//GEN-LAST:event_tfManoFocusGained

    private void tfTPersonalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfTPersonalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfTPersonalActionPerformed

    private void tfTPersonalFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfTPersonalFocusGained
        if (modificar==true) {
            casillaSelect=tfTPersonal.getText();
        }
    }//GEN-LAST:event_tfTPersonalFocusGained

    private void tfTEmpresaFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfTEmpresaFocusGained
        if (modificar==true) {
            casillaSelect=tfTEmpresa.getText();
        }
    }//GEN-LAST:event_tfTEmpresaFocusGained

    private void tfSalarioFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfSalarioFocusGained
        if (modificar==true) {
            casillaSelect=tfSalario.getText();
        }
    }//GEN-LAST:event_tfSalarioFocusGained

    private void tfNombreFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfNombreFocusLost
        if (modificar==true) {
            if (!casillaSelect.equals(tfNombre.getText()))
                tfNombre.setBackground(Color.green);
        }
    }//GEN-LAST:event_tfNombreFocusLost

    private void tfApeUnoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfApeUnoFocusLost
        if (modificar==true) {
            if (!casillaSelect.equals(tfApeUno.getText()))
                tfApeUno.setBackground(Color.green);
        }
    }//GEN-LAST:event_tfApeUnoFocusLost

    private void tfApeDosFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfApeDosFocusLost
        if (modificar==true) {
            if (!casillaSelect.equals(tfApeDos.getText()))
                tfApeDos.setBackground(Color.green);
        }
    }//GEN-LAST:event_tfApeDosFocusLost

    private void tfCalleFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfCalleFocusGained
        if (modificar==true) {
            casillaSelect=tfCalle.getText();
        }
    }//GEN-LAST:event_tfCalleFocusGained

    private void tfCalleFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfCalleFocusLost
        if (modificar==true) {
            if (!casillaSelect.equals(tfCalle.getText()))
                tfCalle.setBackground(Color.green);
        }
    }//GEN-LAST:event_tfCalleFocusLost

    private void tfPortalFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfPortalFocusLost
        if (modificar==true) {
            if (!casillaSelect.equals(tfPortal.getText()))
                tfPortal.setBackground(Color.green);
        }
    }//GEN-LAST:event_tfPortalFocusLost

    private void tfPisoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfPisoFocusLost
        if (modificar==true) {
            if (!casillaSelect.equals(tfPiso.getText()))
                tfPiso.setBackground(Color.green);
        }
    }//GEN-LAST:event_tfPisoFocusLost

    private void tfManoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfManoFocusLost
        if (modificar==true) {
            if (!casillaSelect.equals(tfMano.getText()))
                tfMano.setBackground(Color.green);
        }
    }//GEN-LAST:event_tfManoFocusLost

    private void tfTPersonalFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfTPersonalFocusLost
        if (modificar==true) {
            if (!casillaSelect.equals(tfTPersonal.getText()))
                tfTPersonal.setBackground(Color.green);
        }
    }//GEN-LAST:event_tfTPersonalFocusLost

    private void tfTEmpresaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfTEmpresaFocusLost
        if (modificar==true) {
            if (!casillaSelect.equals(tfTEmpresa.getText()))
                tfTEmpresa.setBackground(Color.green);
        }
    }//GEN-LAST:event_tfTEmpresaFocusLost

    private void tfSalarioFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfSalarioFocusLost
        if (modificar==true) {
            if (!casillaSelect.equals(tfSalario.getText()))
                tfSalario.setBackground(Color.green);
        }
    }//GEN-LAST:event_tfSalarioFocusLost

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        int resp = JOptionPane.showConfirmDialog(this, "¿Esta seguro?", "Modificar login", JOptionPane.YES_NO_OPTION);
        if (resp==0) {
            String usu = JOptionPane.showInputDialog(this, "Indica el nombre de usuario");
            /*JPasswordField pf = new JPasswordField();
            String pas = JOptionPane.show*/
            JPanel panel = new JPanel();
            JLabel label = new JLabel("Enter a password:");
            JPasswordField pass = new JPasswordField(10);
            panel.add(label);
            panel.add(pass);
            String[] options = new String[]{"Aceptar", "Cancelar"};
            int option = JOptionPane.showOptionDialog(null, panel, "Contraseña",
                                     JOptionPane.NO_OPTION, JOptionPane.PLAIN_MESSAGE,
                                     null, options, options[1]);
            String pas="12345";
            if(option == 0) // pressing OK button
            {
                pas = new String(pass.getPassword());
            }
            ProyectoDAW.cambiarLogin(usu, pas);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        jButton1.doClick();
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        if (modificar)
            JOptionPane.showMessageDialog(this, "Modo modificar activado");
        else
            recogerOpcion("baja");
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
        if (modificar)
            jButton2.doClick();
        else
            recogerOpcion("modificar");
    }//GEN-LAST:event_jMenuItem4ActionPerformed

    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DAdminTrabajador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DAdminTrabajador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DAdminTrabajador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DAdminTrabajador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                DAdminTrabajador dialog = new DAdminTrabajador(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }
    
    public void recogerOpcion(String opcion) {
        String dniTra;
        if (tfDni.getText().isEmpty())
            dniTra = JOptionPane.showInputDialog(this, "Introduzca el dni del usuario que desea "+opcion);
        else
            dniTra = tfDni.getText();
        if (ProyectoDAW.buscarTrabajador(dniTra)==false)
            JOptionPane.showMessageDialog(this, "No se ha encontrado un trabajador con ese dni");
        else {
            if (opcion.equals("modificar")) {
                Trabajador tra = ProyectoDAW.getTrabajadorActual();
                tfDni.setText(tra.getDni());
                tfNombre.setText(tra.getNombre());
                tfApeUno.setText(tra.getApeuno());
                tfApeDos.setText(tra.getApedos());
                tfCalle.setText(tra.getDireccion().getCalle());
                tfPortal.setText(tra.getDireccion().getNumero()+"");
                tfPiso.setText(tra.getDireccion().getPiso()+"");
                tfMano.setText(tra.getDireccion().getMano());
                tfTEmpresa.setText(tra.getTelefonoEmpresa());
                cbCentro.setSelectedIndex(setCentro(tra.getCodigo().getNombre()));
                if (tra.getTelefonoPersonal()!=null)
                    tfTPersonal.setText(tra.getTelefonoPersonal());
                if (tra.getSalario()!=null)
                    tfSalario.setText(tra.getSalario()+"");
                try {
                    if (tra.getFechaNac()!=null) {
                        if (dcFNacimiento.isEnabled()==false)
                            jCheckBox1.doClick();
                        sdf = new SimpleDateFormat("yyyy-MM-dd");
                        Calendar cal = Calendar.getInstance();
                        cal.setTime(sdf.parse(tra.getFechaNac()));
                        dcFNacimiento.setSelectedDate(cal);
                    }
                }
                catch (Exception e) {
                    JOptionPane.showMessageDialog(this, "Existen errores mostrando la fecha.\n"+e.getMessage());
                }
                modificar=true;
                jButton3.setEnabled(true);
                cbCentro.setEnabled(false);
                cbTipo.setEnabled(false);
                tfDni.setEnabled(false);
                Font negrita = new Font("Tahoma",Font.BOLD,12);
                jButton2.setForeground(Color.green);
                jButton2.setFont(negrita);
            }
            else {
                ProyectoDAW.borrarTrabajador();
                borrarTextos();
            }
        }
    }
    
    public void mostrarDatos(String dni) {
        if (ProyectoDAW.buscarTrabajador(dni)) {
            JOptionPane.showMessageDialog(this, "Se ha encontrado un trabajador con ese DNI");
            Trabajador tra = ProyectoDAW.getTrabajadorActual();
            tfNombre.setText(tra.getNombre());
            tfApeUno.setText(tra.getApeuno());
            tfApeDos.setText(tra.getApedos());
            tfCalle.setText(tra.getDireccion().getCalle());
            tfPortal.setText(tra.getDireccion().getNumero()+"");
            tfPiso.setText(tra.getDireccion().getPiso()+"");
            tfMano.setText(tra.getDireccion().getMano());
            if (tra.getTelefonoPersonal()!=null)
                tfTPersonal.setText(tra.getTelefonoPersonal());
            tfTEmpresa.setText(tra.getTelefonoEmpresa());
            if (tra.getSalario()!=null)
                tfSalario.setText(tra.getSalario()+"");
            if (ProyectoDAW.buscarTipoTrabajador(tra.getDni()).equalsIgnoreCase("logistica")) cbTipo.setSelectedIndex(0);
            else cbTipo.setSelectedIndex(1);
            if (tra.getFechaNac()!=null) {
                try {
                    if (dcFNacimiento.isEnabled()==false) {
                        cheked = true;
                        jCheckBox1.setSelected(true);
                        dcFNacimiento.setEnabled(true);
                    }
                    Date date = sdf.parse(tra.getFechaNac());
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(date);
                    dcFNacimiento.setSelectedDate(cal);
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(this, "No se ha podido mostrar la fecha: "+e.getMessage());
                }
            }
            cbCentro.setSelectedItem(tra.getCodigo().getNombre());
        }
    }
    
    public boolean comprobarTextos() {
        try {
            Pattern pat = Pattern.compile("^[0-9]{8}[A-Z]$");
            Matcher mat = pat.matcher(tfDni.getText());
            if (mat.matches()==false)
                throw new DatoLogicoException("dni");
            pat =  Pattern.compile("[0-9]");
            mat = pat.matcher(tfNombre.getText());
            if (mat.matches()==true)
                throw new DatoLogicoException("nombre");
            mat = pat.matcher(tfApeUno.getText());
            if (mat.matches()==true)
                throw new DatoLogicoException("primer apellido");
            mat = pat.matcher(tfApeDos.getText());
            if (mat.matches()==true)
                throw new DatoLogicoException("segundo apellido");
            mat = pat.matcher(tfCalle.getText());
            if (mat.matches()==true)
                throw new DatoLogicoException("calle");
            pat = Pattern.compile("^[0-9]{9}$");
            mat = pat.matcher(tfTEmpresa.getText());
            if (mat.matches()==false)
                throw new DatoLogicoException("telefono empresa");
            if (!tfTPersonal.getText().equals("")) {
                mat = pat.matcher(tfTPersonal.getText());
                if (mat.matches()==false)
                    throw new DatoLogicoException("telefono personal");
            }
            pat = Pattern.compile("^([0-9]{1}|[0-9]{2})$");
            mat = pat.matcher(tfPiso.getText());
            if (mat.matches()==false)
                throw new DatoLogicoException("piso");
            mat = pat.matcher(tfPortal.getText());
            if (mat.matches()==false)
                throw new DatoLogicoException("portal");
            pat = Pattern.compile("^([A-F]|[I])$");
            mat = pat.matcher(tfMano.getText());
            if (mat.matches()==false)
                throw new DatoLogicoException("mano");
            if (!tfSalario.getText().equals("")) {
                pat = Pattern.compile("^[0-9]{1,}(|.[0-9]{1,})$");
                mat = pat.matcher(tfSalario.getText());
                if (mat.matches()==false)
                    throw new DatoLogicoException("salario");
            }
            if (tfDni.getText().isEmpty())
                throw new VacioException("dni");
            if (tfNombre.getText().isEmpty())
                throw new VacioException("nombre");
            if (tfApeUno.getText().isEmpty())
                throw new VacioException("primer apellido");
            if (tfApeDos.getText().isEmpty())
                throw new VacioException("segundo apellido");
            if (tfCalle.getText().isEmpty())
                throw new VacioException("calle");
            if (tfPortal.getText().isEmpty())
                throw new VacioException("portal");
            if (tfPiso.getText().isEmpty())
                throw new VacioException("piso");
            if (tfMano.getText().isEmpty())
                throw new VacioException("mano");
            if (tfTEmpresa.getText().isEmpty())
                throw new VacioException("telefono empresa");
            if (cbCentro.getSelectedIndex()==-1)
                throw new VacioException("centro");
            return true;
        }
        catch (DatoLogicoException e) {
            String mano = "";
            if (DatoLogicoException.getMensaje().equals("mano"))
                mano = ".\nLos valores deben ser A,B,C,D,E,F o I.";
            JOptionPane.showMessageDialog(this, "El campo de "+DatoLogicoException.getMensaje()+" no está bien escrito"+mano);
        }
        catch (VacioException e){
            JOptionPane.showMessageDialog(this, "El campo de "+VacioException.getMensaje()+" está vacio");
        }
        return false;
    }
    
    public void borrarTextos() {
        tfDni.setText("");
        tfDni.setBackground(Color.white);
        tfNombre.setText("");
        tfNombre.setBackground(Color.white);
        tfApeUno.setText("");
        tfApeUno.setBackground(Color.white);
        tfApeDos.setText("");
        tfApeDos.setBackground(Color.white);
        tfCalle.setText("");
        tfCalle.setBackground(Color.white);
        tfPortal.setText("");
        tfPortal.setBackground(Color.white);
        tfPiso.setText("");
        tfPiso.setBackground(Color.white);
        tfMano.setText("");
        tfMano.setBackground(Color.white);
        tfTEmpresa.setText("");
        tfTEmpresa.setBackground(Color.white);
        tfTPersonal.setText("");
        tfTPersonal.setBackground(Color.white);
        tfSalario.setText("");
        tfSalario.setBackground(Color.white);
        cbTipo.setSelectedIndex(-1);
        cbCentro.setSelectedIndex(-1);
        Calendar cal = Calendar.getInstance();
        dcFNacimiento.setSelectedDate(cal);
    }
    
    public void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje);
    }
    
    public int setCentro(String nombre) {
        int r = -1;
        for (int x=0;x<cbCentro.getItemCount();x++) {
            cbCentro.setSelectedIndex(x);
            if (cbCentro.getSelectedItem().toString().equals(nombre))
                r=x;
        }
        return r;
    }

    private String casillaSelect;
    private boolean modificar=false;
    private SimpleDateFormat sdf;
    private boolean cheked=false;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbCentro;
    private javax.swing.JComboBox<String> cbTipo;
    private datechooser.beans.DateChooserCombo dcFNacimiento;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JMenu mbAcciones;
    private javax.swing.JTextField tfApeDos;
    private javax.swing.JTextField tfApeUno;
    private javax.swing.JTextField tfCalle;
    private javax.swing.JTextField tfDni;
    private javax.swing.JTextField tfMano;
    private javax.swing.JTextField tfNombre;
    private javax.swing.JTextField tfPiso;
    private javax.swing.JTextField tfPortal;
    private javax.swing.JTextField tfSalario;
    private javax.swing.JTextField tfTEmpresa;
    private javax.swing.JTextField tfTPersonal;
    // End of variables declaration//GEN-END:variables
}
