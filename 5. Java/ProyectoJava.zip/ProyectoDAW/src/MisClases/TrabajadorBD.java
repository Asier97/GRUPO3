package MisClases;

import MisExcepciones.VacioException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import proyectodaw.ProyectoDAW;

public class TrabajadorBD {
    private static GenericoBD gbd;
    
    public static Trabajador buscarTrabajador(String dni) {
        try {
            gbd = new GenericoBD();
            Trabajador trabajador = null;
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("select * from Trabajador where dni=?");
            sentencia.setString(1, dni);
            ResultSet resultado = sentencia.executeQuery();
            if (resultado.next()) {
                //Existe la posibilidad de que los metodos para obtener direccion y centro fallen y devuelvan null. Para controlar esto vamos a poner VacioException
                if (DireccionBD.obtenerDireccionId(resultado.getInt("direccion"))==null||CentroBD.buscarPorId(resultado.getInt("centro"))==null)
                    throw new VacioException("No se han encontrado direccion o centro en buscarTrabador, en trabajador BD");
                else {
                    if (DireccionBD.obtenerDireccionId(resultado.getInt("direccion"))==null&&CentroBD.buscarPorId(resultado.getInt("centro"))==null)
                        throw new VacioException("No se han encontrado direccion ni centro en buscarTrabador, en trabajador BD");
                }
                
                trabajador = new Trabajador(resultado.getString("dni"),resultado.getString("nombre"),resultado.getString("apellido1"),resultado.getString("apellido2"),DireccionBD.obtenerDireccionId(resultado.getInt("direccion")),resultado.getString("tel_per"),resultado.getString("tel_emp"),resultado.getDouble("salario"),resultado.getDate("fecha_nac").toString(),CentroBD.buscarPorId(resultado.getInt("centro")));
            }
            gbd.cerrarConexion();
            return trabajador;
        }
        catch (VacioException e) {
            ProyectoDAW.toDAdminTrabajador(VacioException.getMensaje());
            return null;
        }
        catch (Exception e) {
            ProyectoDAW.toDAdminTrabajador("Problemas en buscarTrabajador, en TrabajadorBD: " + e.getMessage());
            return null;
        }
    }
    
    public static String obtenerTipo(String dni) {
        try {
            gbd = new GenericoBD();
            String a = "No se ha encontrado el trabajador";
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("select * from Trabajador where dni=?");
            sentencia.setString(1, dni);
            ResultSet resultado = sentencia.executeQuery();
            if (resultado.next()) {
                a = resultado.getString("tipo");
                
            }
            gbd.cerrarConexion();
            return a;
        }
        catch (Exception e) {
            ProyectoDAW.toDAdminTrabajador("Problemas en obtenerTipo, en TrabajadorBD: " + e.getMessage());
            return null;
        }
    }
    
    public static void insertarTrabajador(Trabajador tra, String tipo) {
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("insert into Trabajador values (?,?,?,?,?,?,?,?,?,?,?)");
            sentencia.setString(1, tra.getDni());
            sentencia.setString(2, tra.getNombre());
            sentencia.setString(3, tra.getApeuno());
            sentencia.setString(4, tra.getApedos());
            sentencia.setInt(5, tra.getDireccion().getId());
            sentencia.setInt(6, Integer.parseInt((tra.getTelefonoEmpresa())));
            //tratamiento de nulls. En caso de null insertar 0 o 2000-1-1 como fecha
            int x=0;
            if (tra.getTelefonoPersonal()!=null) {
                x=Integer.parseInt(tra.getTelefonoPersonal());
            }
            sentencia.setInt(7, x);
            Double y=0.0;
            if (tra.getSalario()!=null) {
                y=tra.getSalario();
            }
            sentencia.setDouble(8, y);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date fecha = sdf.parse("2000-01-01");
            java.sql.Date sqlfecha = new java.sql.Date(fecha.getTime());
            if (tra.getFechaNac()!=null) {
                fecha = sdf.parse(tra.getFechaNac());
                sqlfecha = new java.sql.Date(fecha.getTime());
            }
            sentencia.setDate(9, sqlfecha);
            sentencia.setString(10, tipo);
            sentencia.setInt(11, tra.getCodigo().getCodigo());
            sentencia.executeUpdate();
            ProyectoDAW.toVAdministracion("Trabajador insertado");
            gbd.cerrarConexion();
        }
        catch (Exception e) {
            ProyectoDAW.toVAdministracion("Problemas en insertarTrabajador, en TrabajadorBD: " + e.getMessage());
        }
    }
    
    public static void actualizarTrabajador(Trabajador tra) {
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("update trabajador set nombre=?, apellido1=?, apellido2=?, direccion=?, tel_emp=?, tel_per=?, salario=?, fecha_nac=? where dni=?");
            sentencia.setString(1, tra.getNombre());
            sentencia.setString(2, tra.getApeuno());
            sentencia.setString(3, tra.getApedos());
            sentencia.setInt(4, tra.getDireccion().getId());
            sentencia.setInt(5, Integer.parseInt((tra.getTelefonoEmpresa())));
            sentencia.setInt(6, Integer.parseInt((tra.getTelefonoPersonal())));
            sentencia.setDouble(7, tra.getSalario());
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date fecha = sdf.parse(tra.getFechaNac());
            java.sql.Date sqlfecha = new java.sql.Date(fecha.getTime());
            sentencia.setDate(8, sqlfecha);
            sentencia.setString(9, tra.getDni());
            sentencia.executeUpdate();
            ProyectoDAW.toVAdministracion("Trabajador actualizado");
            gbd.cerrarConexion();
        }
        catch (Exception e) {
            ProyectoDAW.toVAdministracion("Problemas en actualizarTrabajador, en TrabajadorBD: " + e.getMessage());
        }
    }
    
    public static void borrarTrabajador(Trabajador tra) {
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("delete from Trabajador where dni=?");
            sentencia.setString(1, tra.getDni());
            sentencia.executeUpdate();
            ProyectoDAW.toVAdministracion("Trabajador eliminado");
            gbd.cerrarConexion();
        }
        catch (Exception e) {
            ProyectoDAW.toVAdministracion("Problemas en borrarTrabajador, en TrabajadorBD: " + e.getMessage());
        }
    }
}
