package MisClases;

public class Administrador extends Trabajador{

    public Administrador() {
    }

    public Administrador(String dni, String nombre, String apeuno, String apedos, Direccion direccion, String telefonoPersonal, String telefonoEmpresa, Double salario, String fechaNac, Centro codigo) {
        super(dni, nombre, apeuno, apedos, direccion, telefonoPersonal, telefonoEmpresa, salario, fechaNac, codigo);
    }
    
}
