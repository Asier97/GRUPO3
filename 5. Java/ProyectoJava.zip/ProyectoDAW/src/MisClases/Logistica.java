package MisClases;

public class Logistica extends Trabajador{

    public Logistica() {
    }
    
    public Logistica(String dni, String nombre, String apeuno, String apedos, Direccion direccion, String telefonoPersonal, String telefonoEmpresa, Double salario, String fechaNac, Centro codigo) {
        super(dni, nombre, apeuno, apedos, direccion, telefonoPersonal, telefonoEmpresa, salario, fechaNac, codigo);
    }
    
}
