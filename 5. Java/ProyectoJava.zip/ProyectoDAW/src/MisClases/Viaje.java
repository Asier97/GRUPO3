package MisClases;

public class Viaje {
    private Integer idViaje;
    private Double horaIni;
    private Double horaFin;
    private Parte albaran;
    
    public Viaje(Double horaIni, Double horaFin, Parte albaran) {
        this.horaIni = horaIni;
        this.horaFin = horaFin;
        this.albaran = albaran;
    }

    public Viaje() {
    }

    public Parte getAlbaran() {
        return albaran;
    }

    public void setAlbaran(Parte albaran) {
        this.albaran = albaran;
    }

    public Integer getIdViaje() {
        return idViaje;
    }

    public void setIdViaje(Integer idViaje) {
        this.idViaje = idViaje;
    }

    public Double getHoraIni() {
        return horaIni;
    }

    public void setHoraIni(Double horaIni) {
        this.horaIni = horaIni;
    }

    public Double getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(Double horaFin) {
        this.horaFin = horaFin;
    }
    
    
}
