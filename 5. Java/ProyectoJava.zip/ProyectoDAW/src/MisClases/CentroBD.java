package MisClases;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
//import java.sql.CallableStatement;
import java.sql.Statement;
import proyectodaw.ProyectoDAW;
//import java.sql.Types;

public class CentroBD {
    private static GenericoBD gbd;
    
    public CentroBD() {
    
    }
    
    public static ArrayList<String> listaNombresCentros() {
        ArrayList<String> listaCen = new ArrayList();
        try {
            gbd = new GenericoBD();
            Statement sentencia = gbd.abrirConexion().createStatement();
            /*CallableStatement datos = gbd.abrirConexion().prepareCall("{call visualizar_lista_centro}");
            datos.registerOutParameter(0,Types.INTEGER);
            datos.registerOutParameter(1, Types.VARCHAR);
            datos.registerOutParameter(2, Types.INTEGER);
            datos.registerOutParameter(3, Types.INTEGER);*/
            ResultSet resultado = sentencia.executeQuery("select nombre from centro");
            while (resultado.next()) {
                listaCen.add(resultado.getString("nombre"));
            }
            return listaCen;
        } 
        catch (Exception e) {
            ProyectoDAW.toDAdminTrabajador("Problemas en ListaCentros " + e.getMessage());
            return listaCen;
        }
    
    }
    
    public static Centro idPorNombre(String nom) {
        try {
            Centro devolverid = null;
            nom=nom.toLowerCase();
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("select * from centro where lower(nombre) = ?");
            sentencia.setString(1, nom);
            ResultSet resultado = sentencia.executeQuery();
            if (resultado.next()) {
                devolverid = new Centro(resultado.getInt("codigo"),resultado.getString("nombre"),DireccionBD.obtenerDireccionId(resultado.getInt("direccion")),resultado.getString("Telefono"));
            }
            return devolverid;
        }
        catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(null ,"Problemas en idPorNombre, en CentroBD: " + e.getMessage());
            return null;
        }
    }
    
    public static Centro buscarPorId(int id) {
        try {
            Centro devolverid = null;
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("select * from centro where codigo = ?");
            sentencia.setInt(1, id);
            ResultSet resultado = sentencia.executeQuery();
            if (resultado.next()) {
                devolverid=new Centro(resultado.getInt("codigo"),resultado.getString("nombre"),DireccionBD.obtenerDireccionId(resultado.getInt("direccion")),resultado.getString("Telefono"));
            }
            return devolverid;
        }
        
        catch (Exception e) {
            ProyectoDAW.toVAdministracion("Problemas en buscarPorId, de CentroBD: " + e.getMessage());
            return null;
        }
    }
    
    public static void insertarCentro(Centro centro) {
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("insert into centro(nombre,direccion,telefono) values (?,?,?)");
            sentencia.setString(1, centro.getNombre());
            sentencia.setInt(2, centro.getDireccion().getId());
            sentencia.setInt(3, Integer.parseInt(centro.getTelefono()));
            sentencia.executeUpdate();
            ProyectoDAW.toVAdministracion("Centro insertado");
            gbd.cerrarConexion();
        }
        catch (Exception e) {
            ProyectoDAW.toVAdministracion("Problemas en insertarCentro, de CentroBD: " + e.getMessage());
        }
    }
    
    public static void actualizarCentro(Centro centro) {
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("update centro set nombre = ?, direccion = ?, telefono = ? where codigo=?");
            sentencia.setString(1, centro.getNombre());
            sentencia.setInt(2, centro.getDireccion().getId());
            sentencia.setInt(3, Integer.parseInt(centro.getTelefono()));
            sentencia.setInt(4, centro.getCodigo());
            sentencia.executeUpdate();
            ProyectoDAW.toVAdministracion("Centro actualizado");
            gbd.cerrarConexion();
        }
        catch (Exception e) {
            ProyectoDAW.toVAdministracion("Problemas en actualizarCentro, de CentroBD: " + e.getMessage());
        }
    }
    
    public static void borrarCentro(Centro centro) {
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("delete from centro where codigo=?");
            sentencia.setInt(1, centro.getCodigo());
            sentencia.executeUpdate();
            ProyectoDAW.toVAdministracion("Centro borrado");
            gbd.cerrarConexion();
        } catch (Exception e) {
            ProyectoDAW.toDAdminTrabajador("Problemas en borrarCentro "+e.getMessage());
        }
    }
}
