package MisClases;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import proyectodaw.ProyectoDAW;

public class VehiculoBD {
    private static GenericoBD gbd;

    public VehiculoBD() {
    
    }
    
    public static Vehiculo comprobarMatricula(String mat) {
        Vehiculo devolver=null;
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("select * from vehiculo");
            ResultSet resu = sentencia.executeQuery();
            while (resu.next()) {
                if (resu.getString("matricula").equals(mat)) {
                    devolver=new Vehiculo(resu.getString("matricula"),resu.getString("modelo"),resu.getString("marca"),resu.getInt("peso"));
                }
            }
            gbd.cerrarConexion();
            return devolver;
        } 
        catch (Exception e) {
            ProyectoDAW.toVAdministracion("Problemas en comprobarMatricula " + e.getMessage());
            return devolver;
        } 
    }
    
    public static void insertarVehiculo(Vehiculo ve) {
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("insert into Vehiculo values (?,?,?,?)");
            sentencia.setString(1, ve.getMatricula());
            sentencia.setString(2, ve.getMarca());
            sentencia.setString(3, ve.getModelo());
            sentencia.setInt(4, ve.getPeso());
            sentencia.executeUpdate();
            gbd.cerrarConexion();
            ProyectoDAW.toVAdministracion("Vehiculo insertado");
        } 
        catch (Exception e) {
            ProyectoDAW.toVAdministracion("Problemas en insertarVehiculo " + e.getMessage());
        } 
    }
    
    public static void modificarVehiculo(Vehiculo ve) {
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("update vehiculo set marca = ?, modelo = ?, peso = ? where matricula = ?");
            sentencia.setString(4, ve.getMatricula());
            sentencia.setString(1, ve.getMarca());
            sentencia.setString(2, ve.getModelo());
            sentencia.setInt(3, ve.getPeso());
            sentencia.executeUpdate();
            gbd.cerrarConexion();
            ProyectoDAW.toVAdministracion("Vehiculo actualizado");
        } 
        catch (Exception e) {
            ProyectoDAW.toVAdministracion("Problemas en modificarVehiculo " + e.getMessage());
        } 
    }
    
    public static void borrarVehiculo(Vehiculo ve) {
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("delete from vehiculo where matricula = ?");
            sentencia.setString(1, ve.getMatricula());
            sentencia.executeUpdate();
            gbd.cerrarConexion();
            ProyectoDAW.toVAdministracion("Vehiculo eliminado");
        } 
        catch (Exception e) {
            ProyectoDAW.toVAdministracion("Problemas en borrarVehiculo " + e.getMessage());
        } 
    }
    
    public static ArrayList<String> listaVehiculos() {
        ArrayList<String> devolver = new ArrayList();
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("select * from vehiculo");
            ResultSet resu = sentencia.executeQuery();
            while (resu.next()) {
                    devolver.add(resu.getString("matricula")+" - "+resu.getString("marca"));
            }
            gbd.cerrarConexion();
        } 
        catch (Exception e) {
            ProyectoDAW.toVAdministracion("Problemas en listaVehiculos " + e.getMessage());
        } 
        return devolver;
    }
}
