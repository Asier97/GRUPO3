package proyectodaw;

import MisClases.*;
import MisExcepciones.DatoLogicoException;
import MisVentanas.*;
import java.util.ArrayList;
import java.util.Date;
import parserinformemensual.DOMParserInforme;

public class ProyectoDAW {
    
    //Ventanas y Dialogos
    private static VPrincipal vprincipal;
    private static DLogin dlogin;
    private static VAdministracion vadministra;
    private static DAdminTrabajador dadmintrabajador;
    private static DAdminCentro dadmincentro;
    private static VLogistica vlogistica;
    private static DOpcion dopcion;
    private static DAdminVehiculos dadminvehiculo;
    private static DAdminParte dadminparte;
    private static DViaje dviaje;
    
    //Variables globales utiles
    private static Trabajador trabajadoractual;
    private static Centro centroactual;
    private static Vehiculo vehiculoactual;

    public static void main(String[] args) {
        vprincipal = new VPrincipal();
        vprincipal.setVisible(true);
        mostrarLogin();
    }
    
    /* -=-=-=-=-=-=-=-=-=-=-=-= */
    /* -=- GESTION PROYECTO =-= */
    /* -=-=-=-=-=-=-=-=-=-=-=-= */
    
    public static void inicioRoot() {
        cerrarLogin();
        VRoot root = new VRoot();
        root.setVisible(true);
    }
    
    public static void cerrarProyecto() {
        System.exit(0);
    }
    
    /* ------- */
    /* Parsers */
    /* ------- */
    
    public static void iniciarParse(String dni) {
        try {
        DOMParserInforme.runExample(obtenerPartesTrabajador(dni));
        } catch (Exception e) {
            toVAdministracion("Error mostrando partes: "+e.getMessage());
        }
    }
    
    /* ----------------- */
    /* Gestion de Vistas */
    /* ----------------- */
    
    //Aquí tendremos metodos que mandaran mensajes del constructor o de las clases BD a las ventanas
    
    public static void toVAdministracion(String mensaje) {
        vadministra.mostrarMensaje(mensaje);
    }
    
    public static void toDLogin(String mensaje) {
        dlogin.mostrarMensaje(mensaje);
    }
    
    public static void toDAdminTrabajador(String mensaje) {
        dadmintrabajador.mostrarMensaje(mensaje);
    }
    
    public static void toVLogistica(String mensaje) {
        vlogistica.mostrarMensaje(mensaje);
    }
    
    /* ----------------- */
    /* Login de usuarios */
    /* ----------------- */
    
    public static void mostrarLogin() {
        dlogin = new DLogin(vprincipal, true);
        dlogin.setVisible(true);
    }
    
    public static void cerrarLogin() {
        dlogin.dispose();
    }
    
    public static void login(String usuario, String contrasenya) throws Exception {
        String a = MisClases.LoginBD.logearUsuario(usuario, contrasenya);
        if (a.equalsIgnoreCase("L")||a.equalsIgnoreCase("A")) {
            cerrarLogin();
            String b = MisClases.LoginBD.obtenerNombre(usuario, contrasenya);
            if (a.equalsIgnoreCase("L")){
                mostrarLogistica();
            }
            else {
                mostrarAdministracion(b);
            }
        }
        else {
            toDLogin(a);
            dlogin.contaErrores();
        }
    }
    
    public static void cambiarLogin(String usu, String pas) {
        LoginBD.modificarLogin(usu, pas, trabajadoractual.getDni());
    }
    
    /* -=-=-=-=-=-=-=-=-=-=-=-= */
    /* -=-= ADMINISTRACION -=-= */
    /* -=-=-=-=-=-=-=-=-=-=-=-= */
    
    public static void mostrarAdministracion(String nombre) {
        vadministra = new VAdministracion(nombre);
        vadministra.setVisible(true);
    }
    
    public static void cerrarAdministracion() {
        vadministra.dispose();
    }
    
    //Aqui estan los dialogos para dar opciones
    public static void mostrarVentanaOpciones(String padre) {
        dopcion = new DOpcion(null, true, padre);
        dopcion.setVisible(true);
    }
    
    public static void opcionElegida(String opcion, String padre) {
        dopcion.dispose();
        if (padre.equals("trabajador"))
            dadmintrabajador.recogerOpcion(opcion);
        else {
            if (padre.equals("centro"))
                dadmincentro.recogerOpcion(opcion);
            else {
                if (padre.equals("vehiculo"))
                    dadminvehiculo.recogerOpcion(opcion);
            }
        }
    }
    
    /* ----------------------- */
    /* Gestion de trabajadores */
    /* ----------------------- */
    
    public static void mostrarVentanaTrabajadores() {
        dadmintrabajador = new DAdminTrabajador(vadministra, true);
        dadmintrabajador.setVisible(true);
    }
    
    public static void cerrarVentanaTrabajadores() {
        dadmintrabajador.dispose();
    }
    
    public static void insertarTrabajador(String dni, String nombre, String apeuno, String apedos, String calle, int numero, int piso, String mano, String telper, String telemp, Double salario, String fechanac, String centro, String tipo) {
        Direccion dir = new Direccion(calle, numero, piso, mano);
        DireccionBD.registrarDireccionTrabajador(dir);
        dir.setId(DireccionBD.buscarUltimoRegistro());
        Centro cen = CentroBD.idPorNombre(centro);
        Trabajador tra = new Trabajador(dni, nombre, apeuno, apedos, dir, telper, telemp, salario, fechanac, cen);
        TrabajadorBD.insertarTrabajador(tra, tipo);
        LoginBD.crearLogin(nombre, apeuno, apedos, dni);
    }
    
    public static void actualizarTrabajador(Trabajador tra) {
        DireccionBD.actualizarDireccion(tra.getDireccion());
        TrabajadorBD.actualizarTrabajador(tra);
    }
    
    public static void borrarTrabajador() {
        LoginBD.borrarLogin(trabajadoractual.getDni());
        TrabajadorBD.borrarTrabajador(trabajadoractual);
        DireccionBD.borrarDireccion(trabajadoractual.getDireccion());
        trabajadoractual = new Trabajador();
    }
    
    public static boolean buscarTrabajador(String dni) {
        trabajadoractual=TrabajadorBD.buscarTrabajador(dni);
        if (trabajadoractual==null) 
            return false;
        else
            return true;
    }
    
    public static String buscarTipoTrabajador(String dni) {
        return TrabajadorBD.obtenerTipo(dni);
    }
    
    public static Trabajador getTrabajadorActual() {
        return trabajadoractual;
    }
    
    /* ------------------ */
    /* Gestion de Centros */
    /* ------------------ */
    
    public static void mostrarVentanaCentros() {
        dadmincentro = new DAdminCentro(vadministra,true);
        dadmincentro.setVisible(true);
    }
    
    public static void cerrarVentanaCentros() {
        dadmincentro.dispose();
    }
    
    public static ArrayList<String> nombreCentros() {
        return CentroBD.listaNombresCentros();
    }
    
    public static void insertarCentro(String nombre, String telefono, String ciudad, String provincia, String calle, int numero, int cp) {
        Direccion dir = new Direccion(ciudad, provincia, calle, numero, cp);
        DireccionBD.registrarDireccionCentro(dir);
        int idir = DireccionBD.buscarUltimoRegistro();
        dir.setId(idir);
        Centro cen = new Centro(nombre,dir,telefono);
        CentroBD.insertarCentro(cen);
    }
    
    public static Centro buscarCentroPorNombre(String nombre) {
        Centro cen = CentroBD.idPorNombre(nombre);
        centroactual=cen;
        return cen;
    }
    
    public static void actualizarCentro(Centro cen) {
        //se cambian los datos en la ventana
        DireccionBD.actualizarDireccion(cen.getDireccion());
        CentroBD.actualizarCentro(cen);
    }
    
    public static void borrarCentro() {
        CentroBD.borrarCentro(centroactual);
        DireccionBD.borrarDireccion(centroactual.getDireccion());
        centroactual = new Centro();
    }
    
    public static Centro getCentroActual() {
        return centroactual;
    }
    
    /* -------------------- */
    /* Gestion de Vehiculos */
    /* -------------------- */
    
    public static void mostrarVentanaVehiculos() {
        dadminvehiculo = new DAdminVehiculos(vadministra, true);
        dadminvehiculo.setVisible(true);
    }
    
    public static void cerrarVentanaVehiculos() {
        dadminvehiculo.dispose();
    }
    
    public static Vehiculo getVehiculoActual() {
        return vehiculoactual;
    }
    
    public static boolean comprobarMatricula(String mat) {
        boolean nruter = false;
        Vehiculo ve=VehiculoBD.comprobarMatricula(mat);
        if (ve!=null) {
            vehiculoactual=ve;
            nruter = true;
        }
        return nruter;
    }
    
    public static void insertarVehiculo(String marca, String matricula, int peso, String modelo) {
        Vehiculo ve = new Vehiculo(matricula,modelo,marca,peso);
        VehiculoBD.insertarVehiculo(ve);
    }
    
    public static void modificarVehiculo(Vehiculo ve) {
        VehiculoBD.modificarVehiculo(ve);
    }
    
    public static void borrarVehiculo() {
        VehiculoBD.borrarVehiculo(vehiculoactual);
        vehiculoactual=new Vehiculo();
    }
    
    public static ArrayList<String> listaVehiculos() {
        return VehiculoBD.listaVehiculos();
    }
    
    /* ----------------- */
    /* Gestion de Partes */
    /* ----------------- */
    
    public static void mostrarVentanaPartes() {
        dadminparte = new DAdminParte(vadministra, true);
        dadminparte.setVisible(true);
    }
    
    public static void cerrarVentanaPartes() {
        dadminparte.dispose();
    }
    
    
    
    
    /* -=-=-=-=-=-=-=-=-=-=-=- */
    /* -=-=-= LOGISTICA =-=-=- */
    /* -=-=-=-=-=-=-=-=-=-=-=- */
    
    public static void mostrarLogistica() {
        vlogistica = new VLogistica();
        vlogistica.setVisible(true);
    }
    
    public static void cerrarLogistica() {
        vlogistica.dispose();
    }
    
    public static boolean existeParteIncompleto() {
        return ParteBD.existeParteIncompleto();
    }
    
    public static void guardarParteIncompleto(String albaran, String matricula, String DNI, Double kmini, Double kmfin, Double gasoil, Double peaje, Double dietas, Double otros, String incidencias) {
        try {
            String tipo = TrabajadorBD.obtenerTipo(DNI);
            if (!tipo.equals("L"))
                throw new DatoLogicoException("El usuario no es de Logistica");
            Trabajador tra = TrabajadorBD.buscarTrabajador(DNI);
            Vehiculo ve = VehiculoBD.comprobarMatricula(matricula);//no estamos dando ninguna matricula primo
            Date fecha = new Date();
            Parte par = new Parte(albaran,kmini,kmfin,gasoil,peaje,dietas,otros,incidencias,false,ve,tra,fecha);
            if (existeParteIncompleto())
                ParteBD.insertarParteIncompletoExistente(par);
            else
                ParteBD.insertarParteIncompletoNuevo(par);
            
        }
        catch (DatoLogicoException e) {
            toVLogistica(DatoLogicoException.getMensaje());
        }
        
    }
    
    public static void guardarParteCompleto(String albaran, String matricula, String DNI, Double kmini, Double kmfin, Double gasoil, Double peaje, Double dietas, Double otros, String incidencias) {
        try {
            String tipo = TrabajadorBD.obtenerTipo(DNI);
            if (!tipo.equals("L"))
                throw new DatoLogicoException("El usuario no es de Logistica");
            Trabajador tra = TrabajadorBD.buscarTrabajador(DNI);
            Vehiculo ve = VehiculoBD.comprobarMatricula(matricula);//no estamos dando ninguna matricula primo
            Date fecha = new Date();
            Parte par = new Parte(albaran,kmini,kmfin,gasoil,peaje,dietas,otros,incidencias,false,ve,tra,fecha);
            ParteBD.insertarParteCompeto(par);
            
        }
        catch (DatoLogicoException e) {
            toVLogistica(DatoLogicoException.getMensaje());
        }
        
    }
    
    public static Parte obtenerParte(int id) {
        return ParteBD.obtenerParte(id);
    }
    
    public static ArrayList<Parte> obtenerPartesTrabajador(String dni) {
        return ParteBD.obtenerParteTrabajador(dni);
    }
    
    public static int ultimoParte() {
        return ParteBD.obtenerUltimoParte();
    }
    
    public static void validarParte(int id) {
        ParteBD.validarParte(id);
    }
    
    /* ------ */
    /* Viajes */
    /* ------ */
    
    public static void mostrarViajes() {
        dviaje = new DViaje(vlogistica, true);
        dviaje.setVisible(true);
    }
    
    public static void cerrarViajes() {
        dviaje.dispose();
        vlogistica.salir(true);
    }
    
    public static String listaViajes(int id) {
        return ViajeBD.listaViajes(id);
    }
    
    public static void viajesGuardarParte() {
        vlogistica.viajesRegistrarParte();
    }
    
    public static void registrarViaje(Double inicio, Double fin) {
        Parte par = obtenerParte(ultimoParte());
        Viaje vi = new Viaje(inicio,fin,par);
        ViajeBD.insertarViaje(vi);
    }
    
    public static void mostrarViajeTiempoReal(String viaje) {
        vlogistica.aniadirTAviajes(viaje);
    }
    
}
