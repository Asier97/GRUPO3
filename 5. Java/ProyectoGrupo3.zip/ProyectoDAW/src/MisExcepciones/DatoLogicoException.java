package MisExcepciones;

/**
 * Excepcion para Datos Ilogicos
 * Guarda el mensaje de error para luego mostrarlo
 * @version 1.1, 05/05/2017
 * @author Asier Suarez
 */

public class DatoLogicoException extends Exception {
    private static String mensaje;

    public DatoLogicoException(String mensaje) {
        this.mensaje = mensaje;
    }

    public static String getMensaje() {
        return mensaje;
    }
    
}
