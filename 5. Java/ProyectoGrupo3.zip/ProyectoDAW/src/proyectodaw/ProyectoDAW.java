package proyectodaw;

/**
 * La clase controladora.
 * Ordenada por secciones.
 * @version 1.1, 05/05/2017
 * @author Asier Suarez
 */

import MisClases.*;
import MisExcepciones.DatoLogicoException;
import MisVentanas.*;
import java.util.ArrayList;
import java.util.Date;
import parserinformemensual.DOMParserInforme;

public class ProyectoDAW {
    
    //Ventanas y Dialogos
    private static VPrincipal vprincipal;
    private static DLogin dlogin;
    private static VAdministracion vadministra;
    private static DAdminTrabajador dadmintrabajador;
    private static DAdminCentro dadmincentro;
    private static VLogistica vlogistica;
    private static DOpcion dopcion;
    private static DAdminVehiculos dadminvehiculo;
    private static DAdminParte dadminparte;
    private static DViaje dviaje;
    
    //Variables globales utiles
    private static Trabajador trabajadoractual;
    private static Centro centroactual;
    private static Vehiculo vehiculoactual;
    
    // <editor-fold defaultstate="collapsed" desc="Metodo main">
    public static void main(String[] args) {
        vprincipal = new VPrincipal();
        vprincipal.setVisible(true);
        mostrarLogin();
    }
    // </editor-fold>
    
    /* -=-=-=-=-=-=-=-=-=-=-=-= */
    /* -=- GESTION PROYECTO =-= */
    /* -=-=-=-=-=-=-=-=-=-=-=-= */ 
    
    // <editor-fold defaultstate="collapsed" desc="Inicio root">
    
    /** 
     * Permite logearse al usuario root
     */
    public static void inicioRoot() {
        cerrarLogin();
        VRoot root = new VRoot();
        root.setVisible(true);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Cerrar proyecto">
    
    /** 
     * Permite cerrar todo el proyecto
     */
    
    public static void cerrarProyecto() {
        System.exit(0);
    }
    // </editor-fold>
    
    /* ------- */
    /* Parsers */
    /* ------- */
    
    // <editor-fold defaultstate="collapsed" desc="Iniciar parse">
    
    /** 
     * Metodo para iniciar el parse y mostrar la lista de partes
     */
    
    public static void iniciarParse() {
        try {
        DOMParserInforme.runExample(obtenerPartesTrabajador());
        } catch (Exception e) {
            toVAdministracion("Error mostrando partes: "+e.getMessage());
        }
    }
    // </editor-fold>
    
    /* ----------------- */
    /* Gestion de Vistas */
    /* ----------------- */
    
    //Aquí tendremos metodos que mandaran mensajes del constructor o de las clases BD a las ventanas
    
    // <editor-fold defaultstate="collapsed" desc="Para VAdministracion">
    
    /** 
     * Las clases que no son de vistas pueden generar dialogos.
     * Con este metodo sacan el dialogo por la vista VAdministracion
     * @param mensaje El mensaje que se desea sacar por pantalla
     */
    
    public static void toVAdministracion(String mensaje) {
        vadministra.mostrarMensaje(mensaje);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Para DLogin">
    
    /** 
     * Las clases que no son de vistas pueden generar dialogos.
     * Con este metodo sacan el dialogo por la vista DLogin
     * @param mensaje El mensaje que se desea sacar por pantalla
     */
    
    public static void toDLogin(String mensaje) {
        dlogin.mostrarMensaje(mensaje);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Para DAdminTrabajador">
    
    /** 
     * Las clases que no son de vistas pueden generar dialogos.
     * Con este metodo sacan el dialogo por la vista DAdminTrabajador
     * @param mensaje El mensaje que se desea sacar por pantalla
     */
    
    public static void toDAdminTrabajador(String mensaje) {
        dadmintrabajador.mostrarMensaje(mensaje);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Para VLogistica">
    
    /** 
     * Las clases que no son de vistas pueden generar dialogos.
     * Con este metodo sacan el dialogo por la vista VLogistica
     * @param mensaje El mensaje que se desea sacar por pantalla
     */
    
    public static void toVLogistica(String mensaje) {
        vlogistica.mostrarMensaje(mensaje);
    }
    // </editor-fold>
    
    /* ----------------- */
    /* Login de usuarios */
    /* ----------------- */
    
    // <editor-fold defaultstate="collapsed" desc="Mostrar login">
    
    /** 
     * Muestra la ventana de login
     */
    
    public static void mostrarLogin() {
        dlogin = new DLogin(vprincipal, true);
        dlogin.setVisible(true);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Cerrar login">
    
    /** 
     * Cierra la ventana de login
     */
    
    public static void cerrarLogin() {
        dlogin.dispose();
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Realizar login">
    
    /** 
     * Loguea al usuario en la aplicacion
     * @param usuario El usuario del trabajador
     * @param contrasenya su contraseña
     */
    
    public static void login(String usuario, String contrasenya) throws Exception {
        String a = MisClases.LoginBD.logearUsuario(usuario, contrasenya);
        if (a.equalsIgnoreCase("L")||a.equalsIgnoreCase("A")) {
            cerrarLogin();
            String b = MisClases.LoginBD.obtenerNombre(usuario, contrasenya);
            if (a.equalsIgnoreCase("L")){
                mostrarLogistica();
            }
            else {
                mostrarAdministracion(b);
            }
        }
        else {
            toDLogin(a);
            dlogin.contaErrores();
        }
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Modificar login">
    
    /** 
     * Cambia el login de un usuario
     * @param usu El usuario del trabajador
     * @param pas su contraseña
     */
    
    public static void cambiarLogin(String usu, String pas) {
        LoginBD.modificarLogin(usu, pas, trabajadoractual.getDni());
    }
    // </editor-fold>
    
    /* -=-=-=-=-=-=-=-=-=-=-=-= */
    /* -=-= ADMINISTRACION -=-= */
    /* -=-=-=-=-=-=-=-=-=-=-=-= */  
    
    // <editor-fold defaultstate="collapsed" desc="Mostrar ventana administracion">
    
    /** 
      * Muestra la ventana de Administracion
      * @param nombre el nombre del trabajador para saludarle
      */
    
    public static void mostrarAdministracion(String nombre) {
        vadministra = new VAdministracion(nombre);
        vadministra.setVisible(true);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Cerrar ventana administracion">
    
    /** 
      * Cierra la ventana de administracion
      */
    
    public static void cerrarAdministracion() {
        vadministra.dispose();
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Mostrar ventana de opciones">
    
    /** 
      * Muestra la ventana de opciones para modificar/borrar un objeto
      * @param padre indica que ventana llama a este metodo
      * Puede ser llamada por vehiculo, trabajador o centro
      */
    
    public static void mostrarVentanaOpciones(String padre) {
        dopcion = new DOpcion(null, true, padre);
        dopcion.setVisible(true);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Seleccionar la opcion elegida">
    
    /** 
      * Indica si borrar o modificar el objeto
      * @param opcion recoge la opcion elegida (borrar/modificar)
      * @param padre indica a que ventana llevar los datos
      */
    
    public static void opcionElegida(String opcion, String padre) {
        dopcion.dispose();
        if (padre.equals("trabajador"))
            dadmintrabajador.recogerOpcion(opcion);
        else {
            if (padre.equals("centro"))
                dadmincentro.recogerOpcion(opcion);
            else {
                if (padre.equals("vehiculo"))
                    dadminvehiculo.recogerOpcion(opcion);
            }
        }
    }
    // </editor-fold>
    
    /* ----------------------- */
    /* Gestion de trabajadores */
    /* ----------------------- */
    
    // <editor-fold defaultstate="collapsed" desc="Mostrar ventana de trabajadores">
    
    /** 
      * Muestra la ventana de trabajadores
      */
    public static void mostrarVentanaTrabajadores() {
        dadmintrabajador = new DAdminTrabajador(vadministra, true);
        dadmintrabajador.setVisible(true);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Cerrar ventana de trabajadores">
    
    /** 
      * Cerrar la ventana de trabajadores
      */
    
    public static void cerrarVentanaTrabajadores() {
        dadmintrabajador.dispose();
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Insertar trabajador a la base de datos">
    
    /** 
      * Inserta un trabajador en la base de datos
      * @param dni del trabajador
      * @param nombre del trabajador
      * @param apeuno primer apellido del trabajador
      * @param apedos segundo apellido del trabajador
      * @param calle la calle en la que vive
      * @param numero portal
      * @param piso su piso
      * @param mano letra del piso (A,B,C...)
      * @param telper su telefono personal (opcional)
      * @param telemp telefono de empresa
      * @param salario cuándo cobra (opcional)
      * @param fechanac fecha de nacimiento (opcional)
      * @param centro centro en el que trabaja
      * @param tipo si es de administracion o logistica
      */
    
    public static void insertarTrabajador(String dni, String nombre, String apeuno, String apedos, String calle, int numero, int piso, String mano, String telper, String telemp, Double salario, String fechanac, String centro, String tipo) {
        Direccion dir = new Direccion(calle, numero, piso, mano);
        DireccionBD.registrarDireccionTrabajador(dir);
        dir.setId(DireccionBD.buscarUltimoRegistro());
        Centro cen = CentroBD.idPorNombre(centro);
        Trabajador tra = new Trabajador(dni, nombre, apeuno, apedos, dir, telper, telemp, salario, fechanac, cen);
        TrabajadorBD.insertarTrabajador(tra, tipo);
        LoginBD.crearLogin(nombre, apeuno, apedos, dni);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Actualizar trabajador en la base de datos">
    
    /** 
      * Actualiza al trabajador en la base de datos
      * @param tra trabajador que debe actualizar
      */
    
    public static void actualizarTrabajador(Trabajador tra) {
        DireccionBD.actualizarDireccion(tra.getDireccion());
        TrabajadorBD.actualizarTrabajador(tra);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Borrar trabajador de la base de datos">
    
    /** 
      * Borrar trabajador de la base de datos
      */
    
    public static void borrarTrabajador() {
        LoginBD.borrarLogin(trabajadoractual.getDni());
        TrabajadorBD.borrarTrabajador(trabajadoractual);
        DireccionBD.borrarDireccion(trabajadoractual.getDireccion());
        trabajadoractual = new Trabajador();
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Buscar al trabajador por su DNI">
    
    /** 
      * Busca a un trabajador por su DNI
      * @param dni dni del trabajador
      * @return true si existe false si no
      */
    
    public static boolean buscarTrabajador(String dni) {
        trabajadoractual=TrabajadorBD.buscarTrabajador(dni);
        if (trabajadoractual==null) 
            return false;
        else
            return true;
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Obtener el tipo del trabajador por su DNI">
    
    /** 
      * Devuelve el tipo del trabajador: administrador o logistica
      * @param dni dni del trabajador para buscarlo
      * @return el tipo que es
      */
    
    public static String buscarTipoTrabajador(String dni) {
        return TrabajadorBD.obtenerTipo(dni);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Obtener el trabajador actual">
    
    /** 
      * Cuando se detecta un trabajador, este se guarda en trabajadoractual
      * Este metodo devuelve este trabajador
      * @return el trabajador para operar
      */
    
    public static Trabajador getTrabajadorActual() {
        return trabajadoractual;
    }
    // </editor-fold>
    
    /* ------------------ */
    /* Gestion de Centros */
    /* ------------------ */
    
    // <editor-fold defaultstate="collapsed" desc="Mostrar ventana de centros">
    
    /** 
      * Muestra la ventana de centros
      */
    
    public static void mostrarVentanaCentros() {
        dadmincentro = new DAdminCentro(vadministra,true);
        dadmincentro.setVisible(true);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Cerrar ventana de centros">
    
    /** 
      * Cerrar la ventana de centros
      */
    
    public static void cerrarVentanaCentros() {
        dadmincentro.dispose();
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Obtener lista de nombre de todos los centros">
    
    /** 
      * Devuelve todos los nombres de centros para la ventana trabajadores
      * @return la lista de centros
      */
    
    public static ArrayList<String> nombreCentros() {
        return CentroBD.listaNombresCentros();
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Insertar centro en la base de datos">
    
    /** 
      * Inserta un centro en la base de datos
      * @param nombre del centro
      * @param telefono del centro
      * @param ciudad del centro
      * @param provincia del centro
      * @param calle del centro
      * @param numero (portal) del centro
      * @param cp codigo postal del centro
      */
    
    public static void insertarCentro(String nombre, String telefono, String ciudad, String provincia, String calle, int numero, int cp) {
        Direccion dir = new Direccion(ciudad, provincia, calle, numero, cp);
        DireccionBD.registrarDireccionCentro(dir);
        int idir = DireccionBD.buscarUltimoRegistro();
        dir.setId(idir);
        Centro cen = new Centro(nombre,dir,telefono);
        CentroBD.insertarCentro(cen);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Buscar un centro por su nombre">
    
    /** 
      * Devuelve un objeto tipo centro utilizando 
      * el nombre como metodo de busqueda
      * @param nombre del centro
      * @return la lista de centros
      */
    
    public static Centro buscarCentroPorNombre(String nombre) {
        Centro cen = CentroBD.idPorNombre(nombre);
        centroactual=cen;
        return cen;
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Actualizar datos de un centro">
    
    /** 
      * Actualiza los datos del centro en la base de datos
      * @param cen el centro para actualizar
      */
    
    public static void actualizarCentro(Centro cen) {
        //se cambian los datos en la ventana
        DireccionBD.actualizarDireccion(cen.getDireccion());
        CentroBD.actualizarCentro(cen);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Borrar centro de la base de datos">
    
    /** 
      * Elimina el centro de la base de datos
      */
    
    public static void borrarCentro() {
        CentroBD.borrarCentro(centroactual);
        DireccionBD.borrarDireccion(centroactual.getDireccion());
        centroactual = new Centro();
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Obtener el centro actual">
    
    /** 
      * Cuando se selecciona un centro se guarda en centroactual
      * Este metodo devuelve ese centro
      * @return el centro para modificar
      */
    
    public static Centro getCentroActual() {
        return centroactual;
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Poner numero de trabajadores del centro">
    
    /** 
     * Pone el numero de trabajadores del centro
     * @param num numero de trabajadores
     */
    
    public static void ponerNumCentro(int num) {
        dadmincentro.ponerNumero(num+"");
    }
    // </editor-fold>
    
    /* -------------------- */
    /* Gestion de Vehiculos */
    /* -------------------- */
    
    // <editor-fold defaultstate="collapsed" desc="Muestra la ventana de vehiculos">
    
    /** 
      * Muestra la ventana de vehiculos
      */
    
    public static void mostrarVentanaVehiculos() {
        dadminvehiculo = new DAdminVehiculos(vadministra, true);
        dadminvehiculo.setVisible(true);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Cierra la ventana de vehiculos">
    
    /** 
      * Cierra la ventana de vehiculos
      */
    
    public static void cerrarVentanaVehiculos() {
        dadminvehiculo.dispose();
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Obtener el vehiculo actual">
    
    /** 
      * Cuando se selecciona un vehiculo se guarda en centroactual
      * Este metodo devuelve ese vehiculo
      * @return el vehiculo para modificar
      */
    
    public static Vehiculo getVehiculoActual() {
        return vehiculoactual;
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Comprueba si la matricula existe">
    
    /** 
      * Comprueba si existe la matricula
      * @param mat la matricula para comprobar
      * @return true si existe, false si no
      */
    
    public static boolean comprobarMatricula(String mat) {
        boolean nruter = false;
        Vehiculo ve=VehiculoBD.comprobarMatricula(mat);
        if (ve!=null) {
            vehiculoactual=ve;
            nruter = true;
        }
        return nruter;
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Inserta un vehiculo en la base de datos">
    
    /** 
      * Inserta un vehiculo en la base de datos
      * @param marca la marca
      * @param matricula del vehiculo
      * @param peso su peso
      * @param modelo de vehiculo
      */
    
    public static void insertarVehiculo(String marca, String matricula, int peso, String modelo) {
        Vehiculo ve = new Vehiculo(matricula,modelo,marca,peso);
        VehiculoBD.insertarVehiculo(ve);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Modifica un vehiculo">
    
    /** 
      * Modifica un vehiculo
      * @param ve el vehiculo para modificar
      */
    
    public static void modificarVehiculo(Vehiculo ve) {
        VehiculoBD.modificarVehiculo(ve);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Borrar datos de un vehiculo">
    
    /** 
      * Borrar datos de un vehiculo
      */
    
    public static void borrarVehiculo() {
        VehiculoBD.borrarVehiculo(vehiculoactual);
        vehiculoactual=new Vehiculo();
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Obtiene una lista con los vehiculos existentes">
    
    /** 
      * Para rellenar la combo box de partes,
      * este metodo devuelve los vehiculos
      * @return array con los vehiculos
      */
    
    public static ArrayList<String> listaVehiculos() {
        return VehiculoBD.listaVehiculos();
    }
    // </editor-fold>
    
    /* ----------------- */
    /* Gestion de Partes */
    /* ----------------- */
    
    // <editor-fold defaultstate="collapsed" desc="Mostrar la ventana de partes">
    
    /** 
      * Muestra la ventana de partes
      */
    
    public static void mostrarVentanaPartes() {
        dadminparte = new DAdminParte(vadministra, true);
        dadminparte.setVisible(true);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Cierra la ventana de partes">
    
    /** 
      * cierra ventana de partes
      */
    
    public static void cerrarVentanaPartes() {
        dadminparte.dispose();
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Elije que accion realizar desde VADministracion">
    
    /** 
      * Cuando desde la ventana del administrador, se usa la barra de arriba
      * para mostrar la lista o validar un parte, se usa este metodo.
      * La variable x indica a la ventana de partes que hacer
      * @param x si es true muestra lista, si no valida parte
      */
    
    public static void tocarBoton(boolean x) {
        dadminparte.tocarBoton(x);
    }
    // </editor-fold>
    
    /* -=-=-=-=-=-=-=-=-=-=-=- */
    /* -=-=-= LOGISTICA =-=-=- */
    /* -=-=-=-=-=-=-=-=-=-=-=- */
    
    // <editor-fold defaultstate="collapsed" desc="Muestra la ventana de logistica">
    
    /** 
      * Muestra la ventana de logistica
      */
    
    public static void mostrarLogistica() {
        vlogistica = new VLogistica();
        vlogistica.setVisible(true);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Cierra la ventana de logistica">
    
    /** 
      * Cierra la ventana de logistica
      */
    
    public static void cerrarLogistica() {
        vlogistica.dispose();
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Detecta si existe un parte incompleto para mostrarlo">
    
    /** 
      * Detecta si existe un parte incompleto
      * @return si existe, true. Si no, false
      */
    
    public static boolean existeParteIncompleto() {
        return ParteBD.existeParteIncompleto();
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Registrar un parte incompleto">
    
    /**
    * Detecta si ya existe un parte incompleto
    * Si no existe, lo guarda. Si existe, lo actualiza
    * @param albaran trae el albaran del parte incompleto
    * @param matricula trae la matrícula del coche que aparece en el parte
    * @param DNI trae el DNI del trabajador que crea el parte
    * @param kmini trae los kilometros con los que empezó el vehículo
    * @param kmfin trae los kilometros con los que termina la jornada el vehículo
    * @param gasoil trae los gastos en gasoil
    * @param peaje trae los gastos en peajes
    * @param dietas trae los gastos en comida
    * @param otros trae los gastos en otras cosas de la jornada
    * @param incidencias trae las incidencias detectadas durante la jornada
    */
    
    public static void guardarParteIncompleto(String albaran, String matricula, String DNI, Double kmini, Double kmfin, Double gasoil, Double peaje, Double dietas, Double otros, String incidencias) {
        try {
            String tipo = TrabajadorBD.obtenerTipo(DNI);
            if (!tipo.equals("L"))
                throw new DatoLogicoException("El usuario no es de Logistica");
            Trabajador tra = TrabajadorBD.buscarTrabajador(DNI);
            Vehiculo ve = VehiculoBD.comprobarMatricula(matricula);//no estamos dando ninguna matricula primo
            Date fecha = new Date();
            Parte par = new Parte(albaran,kmini,kmfin,gasoil,peaje,dietas,otros,incidencias,false,ve,tra,fecha);
            if (existeParteIncompleto())
                ParteBD.insertarParteIncompletoExistente(par);
            else
                ParteBD.insertarParteIncompletoNuevo(par);
            
        }
        catch (DatoLogicoException e) {
            toVLogistica(DatoLogicoException.getMensaje());
        }
        
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Registrar un parte completo">
    
    /**
      * Guarda el parte completo
      * @param albaran trae el albaran del parte incompleto
      * @param matricula trae la matrícula del coche que aparece en el parte
      * @param DNI trae el DNI del trabajador que crea el parte
      * @param kmini trae los kilometros con los que empezó el vehículo
      * @param kmfin trae los kilometros con los que termina la jornada el vehículo
      * @param gasoil trae los gastos en gasoil
      * @param peaje trae los gastos en peajes
      * @param dietas trae los gastos en comida
      * @param otros trae los gastos en otras cosas de la jornada
      * @param incidencias trae las incidencias detectadas durante la jornada
      */
    
    public static void guardarParteCompleto(String albaran, String matricula, String DNI, Double kmini, Double kmfin, Double gasoil, Double peaje, Double dietas, Double otros, String incidencias) {
        try {
            String tipo = TrabajadorBD.obtenerTipo(DNI);
            if (!tipo.equals("L"))
                throw new DatoLogicoException("El usuario no es de Logistica");
            Trabajador tra = TrabajadorBD.buscarTrabajador(DNI);
            Vehiculo ve = VehiculoBD.comprobarMatricula(matricula);//no estamos dando ninguna matricula primo
            Date fecha = new Date();
            Parte par = new Parte(albaran,kmini,kmfin,gasoil,peaje,dietas,otros,incidencias,false,ve,tra,fecha);
            ParteBD.insertarParteCompeto(par);
            
        }
        catch (DatoLogicoException e) {
            toVLogistica(DatoLogicoException.getMensaje());
        }
        
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Obtiene un parte por su ID">
    
    /** 
      * Obtiene un parte por su ID
      * @param id el id para buscar
      * @return el parte 
      */
    
    public static Parte obtenerParte(int id) {
        return ParteBD.obtenerParte(id);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Obtiene los partes registrados">
    
    /** 
      * Obtiene una lista de todos los partes completos no validados
      * Este metodo es usado por los parsers
      * @return lista de partes
      */
    
    public static ArrayList<Parte> obtenerPartesTrabajador() {
        return ParteBD.obtenerParteTrabajador();
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Obtiene el ultimo parte, normalmente si registrar">
    
    /** 
      * Obtiene el ultimo parte, normalmente si registrar
      * @return el id del ultimo parte
      */
    
    public static int ultimoParte() {
        return ParteBD.obtenerUltimoParte();
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Validar un parte">
    
    /**
     * Validacion un parte por un administrados
     * @param id el id del parte a validar
     */
    
    public static void validarParte(int id) {
        ParteBD.validarParte(id);
    }
    // </editor-fold>
    
    /* ------ */
    /* Viajes */
    /* ------ */
    
    // <editor-fold defaultstate="collapsed" desc="Mostrar la ventana de Viajes">
    
    /** 
     * Muestra la ventana de viajes
     */
    
    public static void mostrarViajes() {
        dviaje = new DViaje(vlogistica, true);
        dviaje.setVisible(true);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Cerrar la ventana de viajes">
    
    /** 
     * Cierra la ventana de viajes
     */
    
    public static void cerrarViajes() {
        dviaje.dispose();
        vlogistica.salir(true);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Dar una lista de viajes a traves del ID">
    
    /** 
     * Muestra la lista de viajes
     * @param id el ID del parte
     * @return lista partes sin validar
     */
    
    public static String listaViajes(int id) {
        return ViajeBD.listaViajes(id);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Permitir registrar un parte incompleto antes de añadir un viaje">
    
    /** 
     * Guarda el parte al insertar un viaje si este no existe
     */
    
    public static void viajesGuardarParte() {
        vlogistica.viajesRegistrarParte();
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Registrar un viaje en la base de datos">
    
    /** 
     * Registra un viaje en la base de datos
     * @param inicio hora de salida
     * @param fin hora de llegada
     */
    
    public static void registrarViaje(Double inicio, Double fin) {
        Parte par = obtenerParte(ultimoParte());
        Viaje vi = new Viaje(inicio,fin,par);
        ViajeBD.insertarViaje(vi);
    }
    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Muestra los viajes en la ventana de partes">
    
    /** 
     * Actualiza la text area de la ventana de parte con los viajes nuevos
     * @param viaje el viaje a mostrar
     */
    
    public static void mostrarViajeTiempoReal(String viaje) {
        vlogistica.aniadirTAviajes(viaje);
    }
    // </editor-fold>
    
}
