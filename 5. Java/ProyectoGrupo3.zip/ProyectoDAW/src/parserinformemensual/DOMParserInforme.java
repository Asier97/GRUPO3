package parserinformemensual;

import MisClases.Parte;
import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class DOMParserInforme  {
    private static ArrayList <Parte> partes;
    private static Document document;
    private static Element element;
    
    public static void runExample(ArrayList<Parte> partarry) throws IOException {        
        partes = partarry;
        createDOMDoc();
        createDOMTree();        
        printToFile();
        xmlHtml();
    }
  
    private static void createDOMDoc() {   
         try {

		DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
                document = docBuilder.newDocument();
		element= document.createElement("informe");
		document.appendChild(element);
            } catch (ParserConfigurationException pce) {
		pce.printStackTrace();
            }
    }
    
    private static void createDOMTree() {   
        Iterator it = partes.iterator();
        while (it.hasNext()) {
            Parte p = (Parte) it.next();
            //For each Contact object  create <contacto> element and attach it to root
           
            element.appendChild(createParteElement(p));
        }
    }
    
    private static Element createParteElement(Parte p) {
                Element parte = document.createElement("partes");
                element.appendChild(parte);
                    
                    Element id = document.createElement("id");
                    id.appendChild(document.createTextNode(p.getId().toString()));
                    parte.appendChild(id);
                    
                    Element albaran = document.createElement("albaran");
                    albaran.appendChild(document.createTextNode(p.getAlbaran()));
                    parte.appendChild(albaran);
                    
                    Element trabajador = document.createElement("trabajador");
                    trabajador.appendChild(document.createTextNode(p.getDni().getNombre()));
                    parte.appendChild(trabajador);
                    
                    Element dni = document.createElement("dni");
                    dni.appendChild(document.createTextNode(p.getDni().getDni()));
                    parte.appendChild(dni);
                    
                    Element kilometros = document.createElement("kilometros");
                    parte.appendChild(kilometros);
                    
                        Element kmIni = document.createElement("kmInicio");
                        kmIni.appendChild(document.createTextNode(p.getKmIni().toString()));
                        kilometros.appendChild(kmIni);
                        
                        Element kmFin = document.createElement("kmFinales");
                        kmFin.appendChild(document.createTextNode(p.getKmFin().toString()));
                        kilometros.appendChild(kmFin);
                        
                    Element gastos = document.createElement("gastos");
                    parte.appendChild(gastos);
                    
                        Element gasoil = document.createElement("gasoil");
                        gasoil.appendChild(document.createTextNode(p.getGastoGasoil().toString()));
                        gastos.appendChild(gasoil);
                        
                        Element peaje = document.createElement("peaje");
                        peaje.appendChild(document.createTextNode(p.getGastoPeaje().toString()));
                        gastos.appendChild(peaje);
                        
                        Element dietas = document.createElement("dietas");
                        dietas.appendChild(document.createTextNode(p.getGastoDietas().toString()));
                        gastos.appendChild(dietas);
                        
                        Element otros = document.createElement("otros");
                        otros.appendChild(document.createTextNode(p.getGastoOtros().toString()));
                        gastos.appendChild(otros);
                        
                    Element inci = document.createElement("incidencia");
                    inci.appendChild(document.createTextNode(p.getIncidencias()));
                    parte.appendChild(inci);
                    
                    Element valida = document.createElement("validacion");
                    String validado;
                    if (p.isValidacion())
                        validado = "Esta validado";
                    else
                        validado = "No esta validado";
                    valida.appendChild(document.createTextNode(validado));
                    parte.appendChild(valida);
                    
                    Element matri = document.createElement("matricula");
                    matri.appendChild(document.createTextNode(p.getMatricula().getMatricula()));
                    parte.appendChild(matri);
                    
                    
             
                    return parte;
    }
    
    private static void printToFile() {

        try {
            //print
            OutputFormat format = new OutputFormat(document);
            format.setIndenting(true);

            //to generate output to console use this serializer
            //XMLSerializer serializer = new XMLSerializer(System.out, format);

            //to generate a file output use fileoutputstream instead of system.out
            XMLSerializer serializer = new XMLSerializer(
                    new FileOutputStream(new File("partes.xml")), format);

            serializer.serialize(document);

        } catch (IOException ie) {
            ie.printStackTrace();
        }
    }
    
    public static void xmlHtml(){
        try {

    TransformerFactory tFactory = TransformerFactory.newInstance();
    
    Source xslDoc = new StreamSource ("informeMensual.xsl");
    Source xmlDoc = new StreamSource ("partes.xml");
    
    String outputFileName="informeMensual.html";
   
    OutputStream htmlFile=new FileOutputStream(outputFileName);
    Transformer transform = tFactory.newTransformer(xslDoc);
    transform.transform(xmlDoc, new StreamResult(htmlFile));
    Runtime rTime = Runtime.getRuntime();
    Process pc = rTime.exec("C:/Program Files (x86)/Google/Chrome/Application/chrome.exe"+" "+"C:/Users/1GPROG09/Documents/ProyectoDAW/informeMensual.html");
    pc.waitFor();
    
    }
  catch(Exception e){
    e.printStackTrace();
    }
  }

}

