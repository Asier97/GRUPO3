package MisClases;

/**
 * La clase del objeto parte
 * Contiene operaciones en la base de datos
 * @version 1.1, 05/05/2017
 * @author Asier Suarez
 */

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import proyectodaw.ProyectoDAW;

public class ParteBD {
    private static GenericoBD gbd;

    public ParteBD() {
    }
    
    public static boolean existeParteIncompleto() {
        boolean devolver = false;
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("select * from parte_temp");
            ResultSet resu = sentencia.executeQuery();
            if (resu.next()) {
                if (resu.getString("cerrado").equals("no")) {
                    devolver = true;
                }
            }
            gbd.cerrarConexion();
        } 
        catch (Exception e) {
            ProyectoDAW.toVLogistica("Problemas en existeParteIncompleto " + e.getMessage());
        }
        return devolver;
    }
    
    public static Parte obtenerParte(int id) {
        Parte devolver = null;
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("select * from parte where id=?");
            sentencia.setInt(1, id);
            ResultSet resu = sentencia.executeQuery();
            if (resu.next()) {
                ProyectoDAW.comprobarMatricula(resu.getString("matricula"));
                Vehiculo ve = ProyectoDAW.getVehiculoActual();
                ProyectoDAW.buscarTrabajador(resu.getString("DNI"));
                Trabajador tra = ProyectoDAW.getTrabajadorActual();
                boolean booleano;
                if (resu.getString("validacion").equalsIgnoreCase("si"))
                    booleano = true;
                else
                    booleano = false;
                devolver = new Parte(resu.getString("albaran"),resu.getDouble("km_inicio"),resu.getDouble("km_final"),resu.getDouble("gasto_gasoil"),resu.getDouble("gasto_peaje"),resu.getDouble("gasto_dietas"),resu.getDouble("gasto_otros"),resu.getString("incidencias"),booleano,ve,tra,resu.getDate("fecha"));
                devolver.setId(id);
            }
            gbd.cerrarConexion();
        } 
        catch (Exception e) {
            ProyectoDAW.toVLogistica("Problemas en existeParteIncompleto " + e.getMessage());
        }
        return devolver;
    }
    
    public static void insertarParteIncompletoNuevo(Parte par) {
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("insert into parte(albaran,matricula,dni,km_inicio,km_final,gasto_gasoil,gasto_peaje,gasto_dietas,gasto_otros,fecha,validacion,incidencias) values (?,?,?,?,?,?,?,?,?,?,?,?)");
            sentencia.setString(1, par.getAlbaran());
            sentencia.setString(2, par.getMatricula().getMatricula());
            sentencia.setString(3, par.getDni().getDni());
            sentencia.setDouble(4, par.getKmIni());
            sentencia.setDouble(5, par.getKmFin());
            sentencia.setDouble(6, par.getGastoGasoil());
            sentencia.setDouble(7, par.getGastoPeaje());
            sentencia.setDouble(8, par.getGastoDietas());
            sentencia.setDouble(9, par.getGastoOtros());
            java.sql.Date dsql = new java.sql.Date(par.getFecha().getTime());
            sentencia.setDate(10, dsql);
            sentencia.setString(11, "no");
            sentencia.setString(12, par.getIncidencias());
            sentencia.executeUpdate();
            sentencia = gbd.abrirConexion().prepareStatement("insert into parte_temp values (?,?)");
            sentencia.setInt(1, obtenerUltimoParte());
            sentencia.setString(2, "no");
            sentencia.executeUpdate();
            gbd.cerrarConexion();
        } 
        catch (Exception e) {
            ProyectoDAW.toVLogistica("Problemas en insertarParteIncompletoNuevo " + e.getMessage());
        }
    }
    
    public static void insertarParteIncompletoExistente(Parte par) {
        try {
            gbd = new GenericoBD();
            
            int id = 0;
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("select id from parte_temp");
            ResultSet resu = sentencia.executeQuery();
            if (resu.next()) {
                id = resu.getInt("id");
            }
            
            sentencia = gbd.abrirConexion().prepareStatement("update parte set albaran = ?,matricula = ?,dni = ?,km_inicio = ?,km_final = ?,gasto_gasoil = ?,gasto_peaje = ?,gasto_dietas = ?,gasto_otros = ?,fecha = ?,validacion = ?,incidencias = ? where id = ?");
            sentencia.setString(1, par.getAlbaran());
            sentencia.setString(2, par.getMatricula().getMatricula());
            sentencia.setString(3, par.getDni().getDni());
            sentencia.setDouble(4, par.getKmIni());
            sentencia.setDouble(5, par.getKmFin());
            sentencia.setDouble(6, par.getGastoGasoil());
            sentencia.setDouble(7, par.getGastoPeaje());
            sentencia.setDouble(8, par.getGastoDietas());
            sentencia.setDouble(9, par.getGastoOtros());
            java.sql.Date dsql = new java.sql.Date(par.getFecha().getTime());
            sentencia.setDate(10, dsql);
            sentencia.setString(11, "no");
            sentencia.setString(12, par.getIncidencias());
            sentencia.setInt(13, id);
            sentencia.executeUpdate();
            
            gbd.cerrarConexion();
            
        } 
        catch (Exception e) {
            ProyectoDAW.toVLogistica("Problemas en insertarParteIncompletoNuevo " + e.getMessage());
        }
    }
    
    public static void insertarParteCompeto(Parte par) {
        try {
            gbd = new GenericoBD();
            
            int id = 0;
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("select id from parte_temp");
            ResultSet resu = sentencia.executeQuery();
            if (resu.next()) {
                id = resu.getInt("id");
            }
            
            sentencia = gbd.abrirConexion().prepareStatement("update parte set albaran = ?,matricula = ?,dni = ?,km_inicio = ?,km_final = ?,gasto_gasoil = ?,gasto_peaje = ?,gasto_dietas = ?,gasto_otros = ?,fecha = ?,validacion = ?,incidencias = ? where id = ?");
            sentencia.setString(1, par.getAlbaran());
            sentencia.setString(2, par.getMatricula().getMatricula());
            sentencia.setString(3, par.getDni().getDni());
            sentencia.setDouble(4, par.getKmIni());
            sentencia.setDouble(5, par.getKmFin());
            sentencia.setDouble(6, par.getGastoGasoil());
            sentencia.setDouble(7, par.getGastoPeaje());
            sentencia.setDouble(8, par.getGastoDietas());
            sentencia.setDouble(9, par.getGastoOtros());
            java.sql.Date dsql = new java.sql.Date(par.getFecha().getTime());
            sentencia.setDate(10, dsql);
            sentencia.setString(11, "no");
            sentencia.setString(12, par.getIncidencias());
            sentencia.setInt(13, id);
            sentencia.executeUpdate();
            sentencia = gbd.abrirConexion().prepareStatement("delete from parte_temp");
            sentencia.executeUpdate();
            gbd.cerrarConexion();
            ProyectoDAW.toVLogistica("Parte guardado y pendiente de validacion");
        } 
        catch (Exception e) {
            ProyectoDAW.toVLogistica("Problemas en insertarParteCompleto " + e.getMessage());
        }
    }
    
    public static int obtenerUltimoParte() {
        int x = 0;
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("select max(id) from parte");
            ResultSet resu = sentencia.executeQuery();
            if (resu.next())
                x=resu.getInt("max(id)");
            gbd.cerrarConexion();
        } 
        catch (Exception e) {
            ProyectoDAW.toVLogistica("Problemas en obtenerUltimoParte " + e.getMessage());
        }
        return x;
    }
    
    public static ArrayList<Parte> obtenerParteTrabajador() {
        ArrayList<Parte> devolver = new ArrayList();
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("select * from parte");
            ResultSet resu = sentencia.executeQuery();
            if (resu.next()) {
                ProyectoDAW.comprobarMatricula(resu.getString("matricula"));
                Vehiculo ve = ProyectoDAW.getVehiculoActual();
                ProyectoDAW.buscarTrabajador(resu.getString("DNI"));
                Trabajador tra = ProyectoDAW.getTrabajadorActual();
                boolean booleano;
                if (resu.getString("validacion").equalsIgnoreCase("si"))
                    booleano = true;
                else
                    booleano = false;
                Parte par = new Parte(resu.getString("albaran"),resu.getDouble("km_inicio"),resu.getDouble("km_final"),resu.getDouble("gasto_gasoil"),resu.getDouble("gasto_peaje"),resu.getDouble("gasto_dietas"),resu.getDouble("gasto_otros"),resu.getString("incidencias"),booleano,ve,tra,resu.getDate("fecha"));
                par.setId(resu.getInt("id"));
                devolver.add(par);
            }
            gbd.cerrarConexion();
        } 
        catch (Exception e) {
            ProyectoDAW.toVLogistica("Problemas en existeParteIncompleto " + e.getMessage());
        }
        return devolver;
    }
    
    public static void validarParte(int id) {
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("update parte set validacion = ? where id = ?");
            sentencia.setString(1, "no");
            sentencia.setInt(2, id);
            sentencia.executeUpdate();
            gbd.cerrarConexion();
            ProyectoDAW.toVLogistica("Parte validado");
        } 
        catch (Exception e) {
            ProyectoDAW.toVLogistica("Problemas en validarParte " + e.getMessage());
        }
    }
}
