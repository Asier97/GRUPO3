package MisClases;

/**
 * Clase de los trabajadores administradores
 * @version 1.1, 05/05/2017
 * @author Asier Suarez
 */

public class Administrador extends Trabajador{

    public Administrador() {
    }

    public Administrador(String dni, String nombre, String apeuno, String apedos, Direccion direccion, String telefonoPersonal, String telefonoEmpresa, Double salario, String fechaNac, Centro codigo) {
        super(dni, nombre, apeuno, apedos, direccion, telefonoPersonal, telefonoEmpresa, salario, fechaNac, codigo);
    }
    
}
