package MisClases;

import MisExcepciones.VacioException;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import proyectodaw.ProyectoDAW;

public class TrabajadorBD {
    
    private static GenericoBD gbd;
    private static Trabajador trabajador;
    
    public static Trabajador buscarTrabajador(String dni) {
        try {
            gbd = new GenericoBD();
            trabajador = null;
            
            CallableStatement CS =CS = gbd.abrirConexion().prepareCall("{call LECTURA_TRABAJADORES_DNI(?,?,?,?,?,?,?,?,?,?)}");
        
            //Parametros de entrada
            CS.setString(1, dni );

            //Parametros de salida
            //El types.varchar es el mÃ¡s parejo al string
            CS.registerOutParameter(2, Types.VARCHAR ); //NOMBRE
            CS.registerOutParameter(3, Types.VARCHAR ); //APE1
            CS.registerOutParameter(4, Types.VARCHAR ); //APE2
            CS.registerOutParameter(5, Types.INTEGER ); //DIR
            CS.registerOutParameter(6, Types.INTEGER ); //EMP
            CS.registerOutParameter(7, Types.INTEGER ); //PER
            CS.registerOutParameter(8, Types.DOUBLE );  //SAL
            CS.registerOutParameter(9, Types.DATE ); //FECHA
            CS.registerOutParameter(10, Types.INTEGER );//CENTRO
                
            //Ejecutamos el Callable y creamos un resultSet que nos guarde el resultado
            CS.execute();
            
            Centro cen = CentroBD.buscarPorId(CS.getInt(10));
            Direccion dir = DireccionBD.obtenerDireccionId(CS.getInt(5));
            Date date = CS.getDate(9);            
            DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            String text = df.format(date);
            trabajador = new Trabajador(dni, CS.getString(2), CS.getString(3), CS.getString(4), dir, CS.getInt(6)+"", CS.getInt(7)+"", CS.getDouble(8), text, cen);
            //                       String dni, String nombre, String apeuno, String apedos, Direccion direccion, String telefonoPersonal, String telefonoEmpresa, Double salario, String fechaNac, Centro codigo
            gbd.cerrarConexion();
            
        }
        catch (VacioException e) {
            ProyectoDAW.toDAdminTrabajador(VacioException.getMensaje());
            return null;
        }
        catch (SQLException sqle) {
            
        }
        catch (Exception e) {
            ProyectoDAW.toDAdminTrabajador("Problemas en buscarTrabajador, en TrabajadorBD: " + e.getMessage());
            return null;
        }
        return trabajador;
    }
    
    /*public static String obtenerTipo(String dni) {
        String a = "No se ha encontrado el trabajador";
        try {
            gbd = new GenericoBD();
                         
            CallableStatement CS =CS = gbd.abrirConexion().prepareCall("{call LECTURA_TIPO_TRABAJADOR_DNI(?,?)}");
        
            //ParÃ¡metros de entrada
            CS.setString(1, dni );
            //ParÃ¡metros de salida
            CS.registerOutParameter(2, Types.VARCHAR ); //TIPO                       
           
            a = CS.getString(2);
            gbd.cerrarConexion();          
        }
        catch (SQLException sqle) {
            ProyectoDAW.toDAdminTrabajador("Problemas desde la BBDD: " + sqle.getMessage());
        }
        catch (Exception e) {
            ProyectoDAW.toDAdminTrabajador("Problemas en obtenerTipo, en TrabajadorBD: " + e.getMessage());
            return null;
        }
        return a;
    }*/
    public static String obtenerTipo(String dni) {
        try {
            gbd = new GenericoBD();
            String a = "No se ha encontrado el trabajador";
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("select * from Trabajador where dni=?");
            sentencia.setString(1, dni);
            ResultSet resultado = sentencia.executeQuery();
            if (resultado.next()) {
                a = resultado.getString("tipo");
                
            }
            gbd.cerrarConexion();
            return a;
        }
        catch (Exception e) {
            ProyectoDAW.toDAdminTrabajador("Problemas en obtenerTipo, en TrabajadorBD: " + e.getMessage());
            return null;
        }
    }
    
    public static void insertarTrabajador(Trabajador tra, String tipo) {
        try {
            gbd = new GenericoBD();
            CallableStatement CS = gbd.abrirConexion().prepareCall("{call INSERTAR_TRABAJADOR(?,?,?,?,?,?,?,?,?,?,?)}");
            CS.setString(1, tra.getDni());
            CS.setString(2, tra.getNombre());
            CS.setString(3, tra.getApeuno());
            CS.setString(4, tra.getApedos());
            CS.setInt(5, tra.getDireccion().getId());
            CS.setInt(6, Integer.parseInt((tra.getTelefonoEmpresa())));
            //tratamiento de nulls. En caso de null insertar 0 o 2000-1-1 como fecha
            int x=0;
            if (tra.getTelefonoPersonal()!=null) {
                x=Integer.parseInt(tra.getTelefonoPersonal());
            }
            CS.setInt(7, x);
            Double y=0.0;
            if (tra.getSalario()!=null) {
                y=tra.getSalario();
            }
            CS.setDouble(8, y);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date fecha = sdf.parse("2000-01-01");
            java.sql.Date sqlfecha = new java.sql.Date(fecha.getTime());
            if (tra.getFechaNac()!=null) {
                fecha = sdf.parse(tra.getFechaNac());
                sqlfecha = new java.sql.Date(fecha.getTime());
            }
            CS.setDate(9, sqlfecha);
            CS.setString(10, tipo);
            CS.setInt(11, tra.getCodigo().getCodigo());
            CS.executeUpdate();
            ProyectoDAW.toVAdministracion("Trabajador insertado");
            gbd.cerrarConexion();
        }
        catch (Exception e) {
            ProyectoDAW.toVAdministracion("Problemas en insertarTrabajador, en TrabajadorBD: " + e.getMessage());
        }
    }
    
    public static void actualizarTrabajador(Trabajador tra) {
        try {
            gbd = new GenericoBD();
            CallableStatement CS = gbd.abrirConexion().prepareCall("{call ACTUALIZAR_TRABAJADOR(?,?,?,?,?,?,?,?,?)}");
            CS.setString(1, tra.getNombre());
            CS.setString(2, tra.getApeuno());
            CS.setString(3, tra.getApedos());
            CS.setInt(4, tra.getDireccion().getId());
            CS.setInt(5, Integer.parseInt((tra.getTelefonoEmpresa())));
            CS.setInt(6, Integer.parseInt((tra.getTelefonoPersonal())));
            CS.setDouble(7, tra.getSalario());
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date fecha = sdf.parse(tra.getFechaNac());
            java.sql.Date sqlfecha = new java.sql.Date(fecha.getTime());
            CS.setDate(8, sqlfecha);
            CS.setString(9, tra.getDni());
            CS.executeUpdate();
            ProyectoDAW.toVAdministracion("Trabajador actualizado");
            gbd.cerrarConexion();
        }
        catch (Exception e) {
            ProyectoDAW.toVAdministracion("Problemas en actualizarTrabajador, en TrabajadorBD: " + e.getMessage());
        }
    }
    
    public static void borrarTrabajador(Trabajador tra) {
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("delete from Trabajador where dni=?");
            sentencia.setString(1, tra.getDni());
            sentencia.executeUpdate();
            ProyectoDAW.toVAdministracion("Trabajador eliminado");
            gbd.cerrarConexion();
        }
        catch (Exception e) {
            ProyectoDAW.toVAdministracion("Problemas en borrarTrabajador, en TrabajadorBD: " + e.getMessage());
        }
    }
}
