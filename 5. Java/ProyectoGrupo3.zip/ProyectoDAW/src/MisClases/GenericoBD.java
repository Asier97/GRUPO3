package MisClases;

/**
 * La clase para conectarse a la base de datos
 * Cierra y abre conexion
 * @version 1.1, 05/05/2017
 * @author Asier Suarez
 */

import java.sql.Connection;
import java.sql.DriverManager;

public class GenericoBD {
    
    private Connection con;
    
    public Connection abrirConexion()throws Exception{       
            Class.forName("oracle.jdbc.OracleDriver");

            String login="daw09";
            String password= "daw09";
            String url = "jdbc:oracle:thin:@SrvOracle:1521:orcl";
            con = DriverManager.getConnection(url,login ,password);
            
            return con;
    }
    
    public void cerrarConexion() throws Exception{
            con.close();
    }
        
    
}
