package MisClases;

/**
 * La clase del objeto parte
 * Contiene los datos del objeto
 * @version 1.1, 05/05/2017
 * @author Asier Suarez
 */

import java.util.Date;

public class Parte {
    private Integer id;
    private String albaran;
    private Double kmIni;
    private Double kmFin;
    private Double gastoGasoil;
    private Double gastoPeaje;
    private Double gastoDietas;
    private Double gastoOtros;
    private String incidencias;
    private boolean validacion;
    private Vehiculo matricula;
    private Trabajador dni;
    private Date fecha;

    public Parte() {
    }

    public Parte(String albaran, Double kmIni, Double kmFin, Double gastoGasoil, Double gastoPeaje, Double gastoDietas, Double gastoOtros, String incidencias, boolean validacion, Vehiculo matricula, Trabajador dni, Date fecha) {
        this.albaran = albaran;
        this.kmIni = kmIni;
        this.kmFin = kmFin;
        this.gastoGasoil = gastoGasoil;
        this.gastoPeaje = gastoPeaje;
        this.gastoDietas = gastoDietas;
        this.gastoOtros = gastoOtros;
        this.incidencias = incidencias;
        this.validacion = validacion;
        this.matricula = matricula;
        this.dni = dni;
        this.fecha = fecha;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAlbaran() {
        return albaran;
    }

    public void setAlbaran(String albaran) {
        this.albaran = albaran;
    }

    public Double getKmIni() {
        return kmIni;
    }

    public void setKmIni(Double kmIni) {
        this.kmIni = kmIni;
    }

    public Double getKmFin() {
        return kmFin;
    }

    public void setKmFin(Double kmFin) {
        this.kmFin = kmFin;
    }

    public Double getGastoGasoil() {
        return gastoGasoil;
    }

    public void setGastoGasoil(Double gastoGasoil) {
        this.gastoGasoil = gastoGasoil;
    }

    public Double getGastoPeaje() {
        return gastoPeaje;
    }

    public void setGastoPeaje(Double gastoPeaje) {
        this.gastoPeaje = gastoPeaje;
    }

    public Double getGastoDietas() {
        return gastoDietas;
    }

    public void setGastoDietas(Double gastoDietas) {
        this.gastoDietas = gastoDietas;
    }

    public Double getGastoOtros() {
        return gastoOtros;
    }

    public void setGastoOtros(Double gastoOtros) {
        this.gastoOtros = gastoOtros;
    }

    public String getIncidencias() {
        return incidencias;
    }

    public void setIncidencias(String incidencias) {
        this.incidencias = incidencias;
    }

    public boolean isValidacion() {
        return validacion;
    }

    public void setValidacion(boolean validacion) {
        this.validacion = validacion;
    }

    public Vehiculo getMatricula() {
        return matricula;
    }

    public void setMatricula(Vehiculo matricula) {
        this.matricula = matricula;
    }

    public Trabajador getDni() {
        return dni;
    }

    public void setDni(Trabajador dni) {
        this.dni = dni;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
    
}
