package MisClases;

/**
 * La clase del objeto direccion
 * Contiene operaciones en la base de datos
 * @version 1.1, 05/05/2017
 * @author Asier Suarez
 */

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import proyectodaw.ProyectoDAW;


public class DireccionBD {
    private static GenericoBD gbd;
    
    public DireccionBD() {
    
    }
    
    public static Direccion obtenerDireccionId(int id) {
        Direccion dir = null;
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("select * from direcciones where id=?");
            sentencia.setInt(1, id);
            ResultSet resultado = sentencia.executeQuery();
            if (resultado.next()) {
                dir = new Direccion(resultado.getInt("id"),resultado.getString("provincia"),resultado.getString("ciudad"),resultado.getString("calle"),resultado.getInt("numero"),resultado.getInt("piso"),resultado.getString("mano"),resultado.getInt("codigo_postal"));
            }
            gbd.cerrarConexion();
            return dir;
        } 
        catch (Exception e) {
            ProyectoDAW.toVAdministracion("Problemas en obtenerDireccionId " + e.getMessage());
            return null;
        } 
    }
    
    public static int buscarUltimoRegistro() {
        int x = 0;
        try {
            gbd = new GenericoBD();
            Statement sentencia = gbd.abrirConexion().createStatement();
            ResultSet resultado = sentencia.executeQuery("select max(id) from direcciones");
            if (resultado.next()) {
                x=resultado.getInt("max(id)");
            }
            gbd.cerrarConexion();
            return x;
        } catch (Exception e) {
            ProyectoDAW.toDAdminTrabajador("Problemas en buscarUltimoRegistro, de DireccionBD "+e.getMessage());
            return x;
        }
    }
    
    public static void registrarDireccionTrabajador(Direccion dir) {
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("insert into direcciones (calle,numero,piso,mano) values (?,?,?,?)");
            sentencia.setString(1, dir.getCalle());
            sentencia.setInt(2, dir.getNumero());
            sentencia.setInt(3, dir.getPiso());
            sentencia.setString(4, dir.getMano());
            sentencia.executeUpdate();
            gbd.cerrarConexion();
        } catch (Exception e) {
            ProyectoDAW.toDAdminTrabajador("Problemas en registrarDireccionTrabajador "+e.getMessage());
        }
    }
    
    public static void registrarDireccionCentro(Direccion dir) {
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("insert into direcciones (provincia,ciudad,calle,numero,codigo_postal) values (?,?,?,?,?)");
            sentencia.setString(1, dir.getProvincia());
            sentencia.setString(2, dir.getCiudad());
            sentencia.setString(3, dir.getCalle());
            sentencia.setInt(4, dir.getNumero());
            sentencia.setInt(5, dir.getCp());
           int n= sentencia.executeUpdate();
            gbd.cerrarConexion();
        } catch (Exception e) {
            ProyectoDAW.toDAdminTrabajador("Problemas en registrarDireccionCentro "+e.getMessage());
        }
    }
    
    public static void actualizarDireccion(Direccion dir) {
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("update direcciones set provincia=?,ciudad=?,calle=?,numero=?,piso=?,mano=?,codigo_postal=? where id=?");
            sentencia.setString(1, dir.getProvincia());
            sentencia.setString(2, dir.getCiudad());
            sentencia.setString(3, dir.getCalle());
            sentencia.setInt(4, dir.getNumero());
            sentencia.setInt(5, dir.getPiso());
            sentencia.setString(6, dir.getMano());
            sentencia.setInt(7, dir.getCp());
            sentencia.setInt(8, dir.getId());
            sentencia.executeUpdate();
            gbd.cerrarConexion();
        } catch (Exception e) {
            ProyectoDAW.toDAdminTrabajador("Problemas en actualizarDireccion "+e.getMessage());
        }
    }
    
    public static void borrarDireccion(Direccion dir) {
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("delete from direcciones where id=?");
            sentencia.setInt(1, dir.getId());
            sentencia.executeUpdate();
            gbd.cerrarConexion();
        } catch (Exception e) {
            ProyectoDAW.toDAdminTrabajador("Problemas en borrarDireccion "+e.getMessage());
        }
    }
}
