package MisClases;

/**
 * La clase del objeto viaje
 * Contiene operaciones en la base de datos
 * @version 1.1, 05/05/2017
 * @author Asier Suarez
 */

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import proyectodaw.ProyectoDAW;

public class ViajeBD {
    
    private static GenericoBD gbd;

    public ViajeBD() {
    }
    
    public static String listaViajes(int id) {
        String devolver = "Hora Inicio - Hora Fin";
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("select * from viaje where id_parte = ?");
            sentencia.setInt(1, id);
            ResultSet resu = sentencia.executeQuery();
            while (resu.next()) {
                devolver = devolver+"\n"+resu.getString("hora_ini")+" - "+resu.getString("hora_fin");
            }
            gbd.cerrarConexion();
            
        } 
        catch (Exception e) {
            ProyectoDAW.toVAdministracion("Problemas en insertarVehiculo " + e.getMessage());
        } 
        return devolver;
    }
    
    public static void insertarViaje(Viaje viaje) {
        try {
            gbd = new GenericoBD();
            PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("insert into viaje(hora_ini,hora_fin,id_parte) values (?,?,?)");
            sentencia.setInt(3, viaje.getAlbaran().getId());
            sentencia.setDouble(1, viaje.getHoraIni());
            sentencia.setDouble(2, viaje.getHoraFin());
            sentencia.executeUpdate();
            gbd.cerrarConexion();
        } 
        catch (Exception e) {
            ProyectoDAW.toVAdministracion("Problemas en insertarVehiculo " + e.getMessage());
        } 
    }
}
