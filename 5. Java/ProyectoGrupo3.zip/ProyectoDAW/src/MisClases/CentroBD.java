package MisClases;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.sql.SQLException;
import java.sql.Types;
import oracle.jdbc.OracleTypes;
import proyectodaw.ProyectoDAW;
//import java.sql.Types;

public class CentroBD {
    private static GenericoBD gbd;
    
    public CentroBD() {
    
    }
    
    public static ArrayList<String> listaNombresCentros() {
        ArrayList<String> listaCen = new ArrayList();
        try {
            gbd = new GenericoBD();
            CallableStatement CS =CS = gbd.abrirConexion().prepareCall("{call GESTIONAR_CENTRO.VISUALIZAR_LISTA_CENTRO(?)}");
           
            CS.registerOutParameter(1, OracleTypes.CURSOR);
            
            CS.execute();
            
            //Statement sentencia = gbd.abrirConexion().createStatement();
            /*CallableStatement datos = gbd.abrirConexion().prepareCall("{call visualizar_lista_centro}");
            datos.registerOutParameter(0,Types.INTEGER);
            datos.registerOutParameter(1, Types.VARCHAR);
            datos.registerOutParameter(2, Types.INTEGER);
            datos.registerOutParameter(3, Types.INTEGER);*/
            ResultSet resultado = null;
            resultado = (ResultSet)CS.getObject(1);
            while (resultado.next()) {
                listaCen.add(resultado.getString("nombre"));
            }
         
        }
        catch(SQLException sqle) {
            ProyectoDAW.toDAdminTrabajador("");
            return listaCen;
        }
        catch (Exception e) {
            ProyectoDAW.toDAdminTrabajador("Problemas en ListaCentros " + e.getMessage());
            return listaCen;
        }
        return listaCen;
    }
    
    public static Centro idPorNombre(String nom) {
        Centro devolverid = null;
        try {           
            // nom=nom.toLowerCase();
            gbd = new GenericoBD();
            CallableStatement CS =CS = gbd.abrirConexion().prepareCall("{call GESTIONAR_CENTRO.VISUALIZAR_DATOS_CENTRO_NOMBRE(?,?,?)}");
            //ENTRADA
            CS.setString(1, nom);
            //SALIDA
            CS.registerOutParameter(2, OracleTypes.CURSOR);
            CS.registerOutParameter(3, Types.INTEGER);
            //int numTrabajadores = CS.getInt(3); // Echarle un vistazo
            CS.execute();
            
            ResultSet resultado = (ResultSet)CS.getObject(2);
            if (resultado.next()) {
                devolverid = new Centro(resultado.getInt("codigo"),resultado.getString("nombre"),DireccionBD.obtenerDireccionId(resultado.getInt("direccion")),resultado.getString("Telefono"));
                ProyectoDAW.ponerNumCentro(CS.getInt(3));
            }
            return devolverid;
        }
        catch(SQLException sqle) {
            ProyectoDAW.toDAdminTrabajador("Problemas al mostrar el centro de la BBDD");
            return devolverid;
        }
        catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(null ,"Problemas en idPorNombre, en CentroBD: " + e.getMessage());
            return null;
        }
    }
    
    public static Centro buscarPorId(int id) {
        Centro devolverid = null;
        try {
            
            gbd = new GenericoBD();
            CallableStatement CS =CS = gbd.abrirConexion().prepareCall("{call GESTIONAR_CENTRO.VISUALIZAR_DATOS_CENTRO_ID(?,?)}");
            //P. entrada
            CS.setInt(1, id);
            //ParÃ¡metros de Salida
            CS.registerOutParameter(2, OracleTypes.CURSOR);
            
            CS.execute();
                       
            ResultSet resultado = (ResultSet)CS.getObject(2);
            if (resultado.next()) {
                devolverid=new Centro(resultado.getInt("codigo"),resultado.getString("nombre"),DireccionBD.obtenerDireccionId(resultado.getInt("direccion")),resultado.getString("Telefono"));               
            }
            return devolverid;
        }
        catch(SQLException sqle) {
            ProyectoDAW.toDAdminTrabajador("Problemas al mostrar el centro de la BBDD");
            return devolverid;
        }
        catch (Exception e) {
            ProyectoDAW.toVAdministracion("Problemas en buscarPorId, de CentroBD: " + e.getMessage());
            return null;
        }
    }
    
    public static void insertarCentro(Centro centro) {
        try {
            gbd = new GenericoBD();
            //PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("insert into centro(nombre,direccion,telefono) values (?,?,?)");
            CallableStatement CS =CS = gbd.abrirConexion().prepareCall("{call GESTIONAR_CENTRO.INSERTAR_DATOS_CENTRO(?,?,?)}");
            //ParÃ¡metros de entrada
            CS.setString(1, centro.getNombre());
            CS.setInt(2, centro.getDireccion().getId());
            CS.setInt(3, Integer.parseInt(centro.getTelefono()));
            CS.executeUpdate();
            ProyectoDAW.toVAdministracion("Centro insertado");
            gbd.cerrarConexion();
        }
        catch (SQLException sqle) {
            ProyectoDAW.toVAdministracion("Problemas en insertarCentro");
        }
        catch (Exception e) {
            ProyectoDAW.toVAdministracion("Problemas en insertarCentro, de CentroBD: " + e.getMessage());
        }
    }
    
    public static void actualizarCentro(Centro centro) {
        try {
            gbd = new GenericoBD();
            //PreparedStatement sentencia = gbd.abrirConexion().prepareStatement("update centro set nombre = ?, direccion = ?, telefono = ? where codigo=?");
            CallableStatement CS =CS = gbd.abrirConexion().prepareCall("{call GESTIONAR_CENTRO.ACTUALIZAR_DATOS_CENTRO(?,?,?,?)}");
            CS.setString(1, centro.getNombre());
            CS.setInt(2, centro.getDireccion().getId());
            CS.setInt(3, Integer.parseInt(centro.getTelefono()));
            CS.setInt(4, centro.getCodigo());
            CS.executeUpdate();
            ProyectoDAW.toVAdministracion("Centro actualizado");
            gbd.cerrarConexion();
        }
        catch (SQLException sqle) {
            ProyectoDAW.toVAdministracion("Problemas en actualizarCentro");
        }
        catch (Exception e) {
            ProyectoDAW.toVAdministracion("Problemas en actualizarCentro, de CentroBD: " + e.getMessage());
        }
    }
    
    public static void borrarCentro(Centro centro) {
        try {
            gbd = new GenericoBD();
            CallableStatement CS =CS = gbd.abrirConexion().prepareCall("{call GESTIONAR_CENTRO.BORRAR_DATOS_CENTRO(?)}");
            CS.setInt(1, centro.getCodigo());
            CS.executeUpdate();
            ProyectoDAW.toVAdministracion("Centro borrado");
            gbd.cerrarConexion();
        }
        catch (SQLException sqle) {
            ProyectoDAW.toVAdministracion("Problemas en borrarCentro");
        }
        catch (Exception e) {
            ProyectoDAW.toDAdminTrabajador("Problemas en borrarCentro "+e.getMessage());
        }
    }
}
