package MisVentanas;

/**
 * Ventana para los trabajadores de Logistica
 * Sirve para introducir partes
 * @version 1.1, 05/05/2017
 * @author Asier Suarez
 */

import MisClases.Parte;
import MisExcepciones.DatoLogicoException;
import MisExcepciones.VacioException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import proyectodaw.ProyectoDAW;

public class VLogistica extends javax.swing.JFrame {

    public VLogistica() {
        initComponents();
        setLocationRelativeTo(null);
        ArrayList<String> array = ProyectoDAW.listaVehiculos();
        for (int x=0;x<array.size();x++) {
            cbVehiculo.insertItemAt(array.get(x), x);
        }
        if (ProyectoDAW.existeParteIncompleto())
            mostrarDatosParteIncompleto();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        tfAlbaran = new javax.swing.JTextField();
        tfDni = new javax.swing.JTextField();
        tfInicio = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        tfFinal = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        tfGasoil = new javax.swing.JTextField();
        tfPeaje = new javax.swing.JTextField();
        tfDietas = new javax.swing.JTextField();
        tfOtros = new javax.swing.JTextField();
        ckGastos = new javax.swing.JCheckBox();
        bViaje = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        taViajes = new javax.swing.JTextArea();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        taIncidencias = new javax.swing.JTextArea();
        bCancelar = new javax.swing.JButton();
        bAceptar = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        cbVehiculo = new javax.swing.JComboBox<>();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Parte");
        setResizable(false);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Partes");

        jLabel1.setText("* Albarán:");

        jLabel3.setText("* DNI:");

        jLabel4.setText("* km inicio:");

        jLabel5.setText("* km fin:");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Gastos"));

        jLabel6.setText("Gasoil:");

        jLabel7.setText("Peaje:");

        jLabel8.setText("Dietas:");

        jLabel9.setText("Otros:");

        tfGasoil.setEnabled(false);

        tfPeaje.setEnabled(false);

        tfDietas.setEnabled(false);

        tfOtros.setEnabled(false);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel8))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tfDietas, javax.swing.GroupLayout.DEFAULT_SIZE, 156, Short.MAX_VALUE)
                    .addComponent(tfGasoil))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(jLabel9))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tfOtros, javax.swing.GroupLayout.DEFAULT_SIZE, 148, Short.MAX_VALUE)
                    .addComponent(tfPeaje))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7)
                    .addComponent(tfGasoil, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfPeaje, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(tfDietas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfOtros, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        ckGastos.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        ckGastos.setText("Gastos");
        ckGastos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ckGastosActionPerformed(evt);
            }
        });

        bViaje.setText("Añadir viaje");
        bViaje.setToolTipText("");
        bViaje.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bViajeActionPerformed(evt);
            }
        });

        taViajes.setEditable(false);
        taViajes.setColumns(20);
        taViajes.setFont(new java.awt.Font("Dialog", 0, 11)); // NOI18N
        taViajes.setRows(5);
        taViajes.setText("                                                                   Viajes");
        jScrollPane1.setViewportView(taViajes);

        jLabel10.setText("Incidencias:");

        taIncidencias.setColumns(20);
        taIncidencias.setRows(5);
        jScrollPane2.setViewportView(taIncidencias);

        bCancelar.setText("Cancelar");
        bCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCancelarActionPerformed(evt);
            }
        });

        bAceptar.setText("Aceptar");
        bAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAceptarActionPerformed(evt);
            }
        });

        jLabel11.setText("* Vehiculo:");

        jMenu3.setText("Ventana");
        jMenu3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenu3ActionPerformed(evt);
            }
        });

        jMenuItem1.setText("Cerrar ventana");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem1);

        jMenuItem2.setText("Cerrar aplicacion");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu3.add(jMenuItem2);

        jMenuBar1.add(jMenu3);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(215, 215, 215))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(ckGastos))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel11))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(tfDni, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(tfInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel5)
                                        .addGap(18, 18, 18)
                                        .addComponent(tfFinal, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(tfAlbaran)
                                    .addComponent(cbVehiculo, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(201, 201, 201)
                        .addComponent(bViaje))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(jLabel10))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(bCancelar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(bAceptar))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 451, Short.MAX_VALUE)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane2))))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(tfAlbaran, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(tfDni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(cbVehiculo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(tfInicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(tfFinal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addComponent(ckGastos)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(bViaje)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel10)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(bCancelar)
                    .addComponent(bAceptar))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jMenu3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenu3ActionPerformed
        
    }//GEN-LAST:event_jMenu3ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        ProyectoDAW.cerrarLogistica();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void ckGastosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ckGastosActionPerformed
        if (ckGastos.isSelected()) {
            tfGasoil.setEnabled(true);
            tfPeaje.setEnabled(true);
            tfDietas.setEnabled(true);
            tfOtros.setEnabled(true);
        }
        else {
            tfGasoil.setEnabled(false);
            tfPeaje.setEnabled(false);
            tfDietas.setEnabled(false);
            tfOtros.setEnabled(false);
        }
    }//GEN-LAST:event_ckGastosActionPerformed

    private void bViajeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bViajeActionPerformed
        salir(false);
        ProyectoDAW.mostrarViajes();
    }//GEN-LAST:event_bViajeActionPerformed

    private void bCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCancelarActionPerformed
        if (comprobarTextos()) {
            String mat = (cbVehiculo.getSelectedItem().toString().charAt(0)+"")+cbVehiculo.getSelectedItem().toString().charAt(1)+cbVehiculo.getSelectedItem().toString().charAt(2)+cbVehiculo.getSelectedItem().toString().charAt(3)+cbVehiculo.getSelectedItem().toString().charAt(4)+cbVehiculo.getSelectedItem().toString().charAt(5)+cbVehiculo.getSelectedItem().toString().charAt(6)+cbVehiculo.getSelectedItem().toString().charAt(7);
            Double fin=0d, gas=0d, pea=0d, die=0d, otr=0d;
            if (tfFinal.getText().isEmpty()==false)
                fin = Double.parseDouble(tfFinal.getText());
            if (ckGastos.isSelected()) {
                if (tfGasoil.getText().isEmpty()==false)
                    gas = Double.parseDouble(tfGasoil.getText());
                if (tfPeaje.getText().isEmpty()==false)
                    pea = Double.parseDouble(tfPeaje.getText());
                if (tfDietas.getText().isEmpty()==false)
                    die = Double.parseDouble(tfDietas.getText());
                if (tfOtros.getText().isEmpty()==false)
                    Double.parseDouble(tfOtros.getText());
            }
            ProyectoDAW.guardarParteIncompleto(tfAlbaran.getText(), mat, tfDni.getText(), Double.parseDouble(tfInicio.getText()), fin, gas, pea, die, otr, taIncidencias.getText());
            if (salir)
                ProyectoDAW.cerrarLogistica();
        }
    }//GEN-LAST:event_bCancelarActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        ProyectoDAW.cerrarProyecto();
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void bAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAceptarActionPerformed
        if (comprobarTextos()) {
            String mat = (cbVehiculo.getSelectedItem().toString().charAt(0)+"")+cbVehiculo.getSelectedItem().toString().charAt(1)+cbVehiculo.getSelectedItem().toString().charAt(2)+cbVehiculo.getSelectedItem().toString().charAt(3)+cbVehiculo.getSelectedItem().toString().charAt(4)+cbVehiculo.getSelectedItem().toString().charAt(5)+cbVehiculo.getSelectedItem().toString().charAt(6)+cbVehiculo.getSelectedItem().toString().charAt(7);
            Double fin=0d, gas=0d, pea=0d, die=0d, otr=0d;
            if (tfFinal.getText().isEmpty()==false)
                fin = Double.parseDouble(tfFinal.getText());
            if (ckGastos.isSelected()) {
                if (tfGasoil.getText().isEmpty()==false)
                    gas = Double.parseDouble(tfGasoil.getText());
                if (tfPeaje.getText().isEmpty()==false)
                    pea = Double.parseDouble(tfPeaje.getText());
                if (tfDietas.getText().isEmpty()==false)
                    die = Double.parseDouble(tfDietas.getText());
                if (tfOtros.getText().isEmpty()==false)
                    Double.parseDouble(tfOtros.getText());
            }
            ProyectoDAW.guardarParteCompleto(tfAlbaran.getText(), mat, tfDni.getText(), Double.parseDouble(tfInicio.getText()), fin, gas, pea, die, otr, taIncidencias.getText());
            ProyectoDAW.cerrarLogistica();
        }
    }//GEN-LAST:event_bAceptarActionPerformed
    /** 
      * Comprueba que los textos estan bien escritos
      * @return true si estan bien escritos, false si no
      */
    public boolean comprobarTextos() {
        try {
            if (tfAlbaran.getText().isEmpty())
                throw new VacioException("albaran");
            if (tfDni.getText().isEmpty())
                throw new VacioException("dni");
            if (cbVehiculo.getSelectedIndex()==-1)
                throw new VacioException("vehiculo");
            if (tfInicio.getText().isEmpty())
                throw new VacioException("km inicio");
            if (ProyectoDAW.buscarTrabajador(tfDni.getText())==false)
                throw new DatoLogicoException("No existe trabajador con ese DNI");
            Float.parseFloat(tfInicio.getText());
            if (tfFinal.getText().isEmpty()==false)
                Float.parseFloat(tfFinal.getText());
            if (ckGastos.isSelected()) {
                if (tfGasoil.getText().isEmpty()==false)
                    Float.parseFloat(tfGasoil.getText());
                if (tfPeaje.getText().isEmpty()==false)
                    Float.parseFloat(tfPeaje.getText());
                if (tfDietas.getText().isEmpty()==false)
                    Float.parseFloat(tfDietas.getText());
                if (tfOtros.getText().isEmpty()==false)
                    Float.parseFloat(tfOtros.getText());
            }
            return true;
        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Algun campo de valores numericos contienen otros caracteres");
        }
        catch (DatoLogicoException e) {
            JOptionPane.showMessageDialog(this, DatoLogicoException.getMensaje());
        }
        catch (VacioException e){
            JOptionPane.showMessageDialog(this, "El campo de "+VacioException.getMensaje()+" está vacio");
        }
        return false;
    }
    
    /** 
      * Detecta si hay un parte incompleto, y en caso de sí, muestra los datos
      */
    public void mostrarDatosParteIncompleto() {
        Parte par = ProyectoDAW.obtenerParte(ProyectoDAW.ultimoParte());
        tfAlbaran.setText(par.getAlbaran());
        tfDni.setText(par.getDni().getDni());
        for (int x=0;x<cbVehiculo.getItemCount();x++) {
            String mat = (cbVehiculo.getItemAt(x).charAt(0)+"")+cbVehiculo.getItemAt(x).charAt(1)+cbVehiculo.getItemAt(x).charAt(2)+cbVehiculo.getItemAt(x).charAt(3)+cbVehiculo.getItemAt(x).charAt(4)+cbVehiculo.getItemAt(x).charAt(5)+cbVehiculo.getItemAt(x).charAt(6)+cbVehiculo.getItemAt(x).charAt(7);
            if (mat.equals(par.getMatricula().getMatricula())) {
                cbVehiculo.setSelectedIndex(x);
                cbVehiculo.setEnabled(false);
            }
        }
        tfInicio.setText(par.getKmIni()+"");
        if (par.getKmFin()!=0)
            tfFinal.setText(par.getKmFin()+"");
        if (par.getGastoDietas()!=0||par.getGastoGasoil()!=0||par.getGastoOtros()!=0||par.getGastoPeaje()!=0) {
            ckGastos.doClick();
            tfGasoil.setText(par.getGastoGasoil()+"");
            tfPeaje.setText(par.getGastoPeaje()+"");
            tfDietas.setText(par.getGastoDietas()+"");
            tfOtros.setText(par.getGastoOtros()+"");
        }
        taViajes.setText(taViajes.getText()+"\n \n"+ProyectoDAW.listaViajes(par.getId()));
        taIncidencias.setText(par.getIncidencias());
    }
    
    /** 
      * Actualiza la textarea en tiempo real con los viajes añadidos
      * @param viaje que se desea añadir
      */
    public void aniadirTAviajes(String viaje) {
        taViajes.setText(taViajes.getText()+"\n"+viaje);
    }
    
    /** 
      * Muestra un mensaje obtenido del controlador
      * @param mensaje a mostrar
      */
    public void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje);
    }
    
    /** 
      * Si no existe ese parte registrado, lo registra
      */
    public void viajesRegistrarParte() {
        JOptionPane.showMessageDialog(this, "No se ha registrado este parte aun.\nSe procedera a registrarlo");
        bCancelar.doClick();
    }
    
    /** 
      * Depende quien registre un parte incompleto, cierra la ventana o no
      * @param salir true si se cierra, false si lo registra viajes y no se cierra
      */
    public void salir(boolean salir) {
        this.salir = salir;
    }
    
    private boolean salir = true;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAceptar;
    private javax.swing.JButton bCancelar;
    private javax.swing.JButton bViaje;
    private javax.swing.JComboBox<String> cbVehiculo;
    private javax.swing.JCheckBox ckGastos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea taIncidencias;
    private javax.swing.JTextArea taViajes;
    private javax.swing.JTextField tfAlbaran;
    private javax.swing.JTextField tfDietas;
    private javax.swing.JTextField tfDni;
    private javax.swing.JTextField tfFinal;
    private javax.swing.JTextField tfGasoil;
    private javax.swing.JTextField tfInicio;
    private javax.swing.JTextField tfOtros;
    private javax.swing.JTextField tfPeaje;
    // End of variables declaration//GEN-END:variables
}
