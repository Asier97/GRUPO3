package MisVentanas;

/**
 * Cuadro de dialogo para administracion de centro
 * Esta ventana siempre es llamada por VAdministracion
 * @version 1.1, 05/05/2017
 * @author Asier Suarez
 */

import MisClases.Centro;
import MisExcepciones.*;
import java.awt.Color;
import java.awt.Font;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import proyectodaw.ProyectoDAW;

public class DAdminCentro extends javax.swing.JDialog {

    public DAdminCentro(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setLocationRelativeTo(null);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        tfNombre = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        tfCiudad = new javax.swing.JTextField();
        tfProvincia = new javax.swing.JTextField();
        tfCalle = new javax.swing.JTextField();
        tfNumero = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        tfCP = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        tfTelefono = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        tfNum = new javax.swing.JTextField();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();

        jScrollPane1.setViewportView(jTextPane1);

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("Administracion de Centros");
        setResizable(false);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("CENTROS");

        jLabel2.setText("Nombre:");

        tfNombre.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tfNombreFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfNombreFocusLost(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Dirección"));

        jLabel3.setText("Calle:");

        jLabel4.setText("Número:");

        jLabel5.setText("Ciudad:");

        jLabel6.setText("Provincia:");

        tfCiudad.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tfCiudadFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfCiudadFocusLost(evt);
            }
        });

        tfProvincia.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tfProvinciaFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfProvinciaFocusLost(evt);
            }
        });

        tfCalle.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tfCalleFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfCalleFocusLost(evt);
            }
        });

        tfNumero.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tfNumeroFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfNumeroFocusLost(evt);
            }
        });

        jLabel7.setText("CP:");

        tfCP.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tfCPFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfCPFocusLost(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(18, 18, 18)
                        .addComponent(tfCP, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tfCiudad, javax.swing.GroupLayout.DEFAULT_SIZE, 105, Short.MAX_VALUE)
                            .addComponent(tfCalle))))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel6))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tfProvincia, javax.swing.GroupLayout.DEFAULT_SIZE, 105, Short.MAX_VALUE)
                    .addComponent(tfNumero))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(tfCiudad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfProvincia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel3)
                    .addComponent(tfCalle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfNumero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(tfCP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel8.setText("Teléfono:");

        tfTelefono.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tfTelefonoFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tfTelefonoFocusLost(evt);
            }
        });

        jButton1.setText("Insertar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Modificar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        tfNum.setEnabled(false);

        jMenu1.setText("Ventana");

        jMenuItem1.setText("Cerrar");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem1);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Acciones");

        jMenuItem2.setText("Insertar");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem2);

        jMenuItem3.setText("Modificar");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem3);

        jMenuItem4.setText("Borrar");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem4);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel2))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tfNombre, javax.swing.GroupLayout.DEFAULT_SIZE, 279, Short.MAX_VALUE)
                            .addComponent(tfTelefono))))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(47, 47, 47))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(tfNum, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(122, 122, 122))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(tfNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(tfNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(tfTelefono, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    
    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        ProyectoDAW.cerrarVentanaCentros();
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void tfNombreFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfNombreFocusLost
        if (modificar==true) {
            if (!casillaSelect.equals(tfNombre.getText()))
                tfNombre.setBackground(Color.green);
        }
        else {
            Centro cen = ProyectoDAW.buscarCentroPorNombre(tfNombre.getText());
            if (cen!=null) {
                JOptionPane.showMessageDialog(this, "Se ha encontrado un centro con ese nombre");
                tfTelefono.setText(cen.getTelefono());
                tfCiudad.setText(cen.getDireccion().getCiudad());
                tfProvincia.setText(cen.getDireccion().getProvincia());
                tfCalle.setText(cen.getDireccion().getCalle());
                tfNumero.setText(cen.getDireccion().getNumero()+"");
                String y = "";
                for (int x = cen.getDireccion().getCp().toString().length();x<5;x++) {
                    y=y+"0";
                }
                
                tfCP.setText(y+cen.getDireccion().getCp());
            }
        }
    }//GEN-LAST:event_tfNombreFocusLost

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if (comprobarTextos()) {
            Centro cen = ProyectoDAW.buscarCentroPorNombre(tfNombre.getText());
            if (cen==null) {
                ProyectoDAW.insertarCentro(tfNombre.getText(), tfTelefono.getText(), tfCiudad.getText(), tfProvincia.getText(), tfCalle.getText(), Integer.parseInt(tfNumero.getText()), Integer.parseInt(tfCP.getText()));
                tfNombre.setText("");
                tfTelefono.setText("");
                tfCiudad.setText("");
                tfProvincia.setText("");
                tfCalle.setText("");
                tfNumero.setText("");
                tfCP.setText("");
            }
            else
                JOptionPane.showMessageDialog(this, "El centro ya existe");
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        jButton1.doClick();
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        if (modificar) {
            if (comprobarTextos()) {
                modificar=false;
                Font normal = new Font("Tahoma",Font.PLAIN,11);
                jButton2.setForeground(Color.black);
                jButton2.setFont(normal);
                Centro cen = ProyectoDAW.getCentroActual();
                if (tfNombre.getBackground()==Color.green)
                    cen.setNombre(tfNombre.getText());
                if (tfTelefono.getBackground()==Color.green)
                    cen.setTelefono(tfTelefono.getText());
                if (tfCiudad.getBackground()==Color.green)
                    cen.getDireccion().setCiudad(tfCiudad.getText());
                if (tfProvincia.getBackground()==Color.green)
                    cen.getDireccion().setProvincia(tfProvincia.getText());
                if (tfCalle.getBackground()==Color.green)
                    cen.getDireccion().setCalle(tfCalle.getText());
                if (tfNumero.getBackground()==Color.green)
                    cen.getDireccion().setNumero(Integer.parseInt(tfNumero.getText()));
                if (tfCP.getBackground()==Color.green)
                    cen.getDireccion().setCp(Integer.parseInt(tfCP.getText()));
                ProyectoDAW.actualizarCentro(cen);
                borrarTextos();
            }
        }
        else
            ProyectoDAW.mostrarVentanaOpciones("centro");
    }//GEN-LAST:event_jButton2ActionPerformed

    private void tfNombreFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfNombreFocusGained
        if (modificar==true) {
            casillaSelect=tfNombre.getText();
        }
    }//GEN-LAST:event_tfNombreFocusGained

    private void tfTelefonoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfTelefonoFocusGained
        if (modificar==true) {
            casillaSelect=tfTelefono.getText();
        }
    }//GEN-LAST:event_tfTelefonoFocusGained

    private void tfCiudadFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfCiudadFocusGained
        if (modificar==true) {
            casillaSelect=tfCiudad.getText();
        }
    }//GEN-LAST:event_tfCiudadFocusGained

    private void tfProvinciaFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfProvinciaFocusGained
        if (modificar==true) {
            casillaSelect=tfProvincia.getText();
        }
    }//GEN-LAST:event_tfProvinciaFocusGained

    private void tfCalleFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfCalleFocusGained
        if (modificar==true) {
            casillaSelect=tfCalle.getText();
        }
    }//GEN-LAST:event_tfCalleFocusGained

    private void tfNumeroFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfNumeroFocusGained
        if (modificar==true) {
            casillaSelect=tfNumero.getText();
        }
    }//GEN-LAST:event_tfNumeroFocusGained

    private void tfCPFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfCPFocusGained
        if (modificar==true) {
            casillaSelect=tfCP.getText();
        }
    }//GEN-LAST:event_tfCPFocusGained

    private void tfTelefonoFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfTelefonoFocusLost
        if (modificar==true) {
            if (!casillaSelect.equals(tfTelefono.getText()))
                tfTelefono.setBackground(Color.green);
        }
    }//GEN-LAST:event_tfTelefonoFocusLost

    private void tfCiudadFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfCiudadFocusLost
        if (modificar==true) {
            if (!casillaSelect.equals(tfCiudad.getText()))
                tfCiudad.setBackground(Color.green);
        }
    }//GEN-LAST:event_tfCiudadFocusLost

    private void tfProvinciaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfProvinciaFocusLost
        if (modificar==true) {
            if (!casillaSelect.equals(tfProvincia.getText()))
                tfProvincia.setBackground(Color.green);
        }
    }//GEN-LAST:event_tfProvinciaFocusLost

    private void tfCalleFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfCalleFocusLost
        if (modificar==true) {
            if (!casillaSelect.equals(tfCalle.getText()))
                tfCalle.setBackground(Color.green);
        }
    }//GEN-LAST:event_tfCalleFocusLost

    private void tfNumeroFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfNumeroFocusLost
        if (modificar==true) {
            if (!casillaSelect.equals(tfNumero.getText()))
                tfNumero.setBackground(Color.green);
        }
    }//GEN-LAST:event_tfNumeroFocusLost

    private void tfCPFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tfCPFocusLost
        if (modificar==true) {
            if (!casillaSelect.equals(tfCP.getText()))
                tfCP.setBackground(Color.green);
        }
    }//GEN-LAST:event_tfCPFocusLost

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        if (modificar)
            jButton2.doClick();
        else
            recogerOpcion("modificar");
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
        if (modificar)
            JOptionPane.showMessageDialog(this, "Modo modificar activado");
        else
            recogerOpcion("borrar");
    }//GEN-LAST:event_jMenuItem4ActionPerformed
  
    /** 
      * Depende lo que elija el usuario, borra o activa la modificacion del centro
      * @param opcion recoge la opcion indicada por el usuario
      */
    public void recogerOpcion(String opcion) {
        String nombreCentro;
        if (tfNombre.getText().isEmpty())
            nombreCentro = JOptionPane.showInputDialog(this, "Introduzca el nombre del centro que desea "+opcion);
        else
            nombreCentro = tfNombre.getText();
        Centro cen = ProyectoDAW.buscarCentroPorNombre(nombreCentro);
        if (cen==null)
            JOptionPane.showMessageDialog(this, "No se ha encontrado un centro con ese nombre");
        else {
            if (opcion.equals("modificar")) {
                tfNombre.setText(cen.getNombre());
                tfTelefono.setText(cen.getTelefono());
                tfCiudad.setText(cen.getDireccion().getCiudad());
                tfProvincia.setText(cen.getDireccion().getProvincia());
                tfCalle.setText(cen.getDireccion().getCalle());
                tfNumero.setText(cen.getDireccion().getNumero()+"");
                tfCP.setText(cen.getDireccion().getCp()+"");
                modificar=true;
                Font negrita = new Font("Tahoma",Font.BOLD,12);
                jButton2.setForeground(Color.green);
                jButton2.setFont(negrita);
            }
            else {
                ProyectoDAW.borrarCentro();
                borrarTextos();
            }
        }
    }
    
    /** 
      * Comprueba si todos los textos estan bien escritos
      * @return true si estan bien, false si algo falla
      */
    public boolean comprobarTextos() {
        try {
            if (tfNombre.getText().isEmpty())
                throw new VacioException("nombre");
            if (tfTelefono.getText().isEmpty())
                throw new VacioException("telefono");
            if (tfCiudad.getText().isEmpty())
                throw new VacioException("ciudad");
            if (tfProvincia.getText().isEmpty())
                throw new VacioException("provincia");
            if (tfCalle.getText().isEmpty())
                throw new VacioException("calle");
            if (tfNumero.getText().isEmpty())
                throw new VacioException("numero");
            if (tfCP.getText().isEmpty())
                throw new VacioException("codigo postal");
            Pattern pat =  Pattern.compile("[0-9]");
            Matcher mat = pat.matcher(tfNombre.getText());
            if (mat.matches()==true)
                throw new DatoLogicoException("nombre");
            mat = pat.matcher(tfCiudad.getText());
            if (mat.matches()==true)
                throw new DatoLogicoException("ciudad");
            mat = pat.matcher(tfProvincia.getText());
            if (mat.matches()==true)
                throw new DatoLogicoException("provincia");
            mat = pat.matcher(tfCalle.getText());
            if (mat.matches()==true)
                throw new DatoLogicoException("calle");
            pat = Pattern.compile("^[0-9]{9}$");
            mat = pat.matcher(tfTelefono.getText());
            if (mat.matches()==false)
                throw new DatoLogicoException("telefono");
            pat = Pattern.compile("^[0-9]{5}$");
            mat = pat.matcher(tfCP.getText());
            if (mat.matches()==false)
                throw new DatoLogicoException("codigo postal");
            pat = Pattern.compile("[A-Za-z]");
            mat = pat.matcher(tfCP.getText());
            if (mat.matches()==true)
                throw new DatoLogicoException("numero");
            return true;
        }
        catch (DatoLogicoException e) {
            JOptionPane.showMessageDialog(this, "El campo de "+DatoLogicoException.getMensaje()+" no está bien escrito");
        }
        catch (VacioException e){
            JOptionPane.showMessageDialog(this, "El campo de "+VacioException.getMensaje()+" está vacio");
        }
        return false;
    }
    
    /** 
      * Borra los textos de todas las cajas
      */
    public void borrarTextos() {
        tfNombre.setText("");
        tfNombre.setBackground(Color.white);
        tfTelefono.setText("");
        tfTelefono.setBackground(Color.white);
        tfCiudad.setText("");
        tfCiudad.setBackground(Color.white);
        tfProvincia.setText("");
        tfProvincia.setBackground(Color.white);
        tfCalle.setText("");
        tfCalle.setBackground(Color.white);
        tfNumero.setText("");
        tfNumero.setBackground(Color.white);
        tfCP.setText("");
        tfCP.setBackground(Color.white);
    }
    
    public void ponerNumero(String num) {
        tfNum.setText(num);
    }

    private String casillaSelect;
    private boolean modificar = false;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextPane jTextPane1;
    private javax.swing.JTextField tfCP;
    private javax.swing.JTextField tfCalle;
    private javax.swing.JTextField tfCiudad;
    private javax.swing.JTextField tfNombre;
    private javax.swing.JTextField tfNum;
    private javax.swing.JTextField tfNumero;
    private javax.swing.JTextField tfProvincia;
    private javax.swing.JTextField tfTelefono;
    // End of variables declaration//GEN-END:variables
}
